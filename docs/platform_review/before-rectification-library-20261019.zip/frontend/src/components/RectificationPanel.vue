<script setup lang="ts">
import { computed,reactive,ref,watch } from 'vue'
import { Upload,Loader2,ShieldCheck,CheckCircle2 } from 'lucide-vue-next'
import EvidenceReview from './EvidenceReview.vue'
import { api } from '../api'
import { errorMessage,toast } from '../store'
import { demoTime,formatDateTime,localDateTime,isoDateTime } from '../utils'
import type { CaseBundle } from '../types'
const props=defineProps<{bundle:CaseBundle}>()
const emit=defineEmits<{updated:[value:CaseBundle]}>()
const busy=ref(''),file=ref<File|null>(null),fileInput=ref<HTMLInputElement|null>(null),selectedId=ref(''),manualConfirmed=ref(false)
const form=reactive({owner:'',implemented_at:'',comment:'按批准的整改措施完成处置。',captured_at:'',reviewer:'演示安全员',as_of:''})
const current=computed(()=>props.bundle.case)
const after=computed(()=>props.bundle.evidence.filter(item=>item.stage==='after'))
const selected=computed(()=>after.value.find(item=>item.evidence_id===selectedId.value) || after.value.at(-1))
const required=computed(()=>Object.values(current.value.review?.verification_snapshot || {}).flatMap(c=>c.manual_requirements || []))
const confirmed=computed(()=>!!selected.value && (selected.value.source!=='upload' || selected.value.perception?.confirmed===true))
watch(()=>current.value.case_id,()=>{
  form.owner=props.bundle.context?.task.owner || '演示机电班组'
  form.implemented_at=current.value.implementation?.implemented_at || demoTime(current.value.review?.reviewed_at || current.value.as_of,10)
  form.captured_at=demoTime(form.implemented_at,10);form.as_of=demoTime(form.captured_at,10)
  file.value=null;selectedId.value='';manualConfirmed.value=false
},{immediate:true})
function fileChanged(event:Event){
  const picked=(event.target as HTMLInputElement).files?.[0] || null
  if(picked && picked.size>20*1024*1024){toast('文件不能超过20MB','warning');return}
  file.value=picked
}
function update(value:CaseBundle){emit('updated',value)}
async function refresh(){emit('updated',await api.get<CaseBundle>(`/cases/${current.value.case_id}`))}
async function submit(){
  if(!file.value || busy.value)return
  if(Date.parse(form.captured_at)<=Date.parse(current.value.implementation?.implemented_at || form.implemented_at)) {toast('整改后照片时刻须晚于整改完成时刻','warning');return}
  busy.value='submit'
  try {
    let value=props.bundle
    if(current.value.status==='approved') {
      value=await api.post<CaseBundle>(`/cases/${current.value.case_id}/implementation`,{owner:form.owner,implemented_at:form.implemented_at,comment:form.comment,expected_case_version:current.value.version})
      update(value)
    }
    const data=new FormData();data.append('file',file.value);data.append('stage','after');data.append('captured_at',form.captured_at);data.append('note',file.value.name)
    const prior=new Set(value.case.evidence_ids)
    value=await api.postForm<CaseBundle>(`/cases/${current.value.case_id}/evidence/upload`,data)
    selectedId.value=value.case.evidence_ids.find(id=>!prior.has(id)) || '';update(value)
    const item=value.evidence.find(e=>e.evidence_id===selectedId.value)
    file.value=null;if(fileInput.value)fileInput.value.value=''
    if(item && /\.(png|jpe?g)$/i.test(item.file_path || '')){
      busy.value='vision'
      try {await api.post(`/cases/${current.value.case_id}/evidence/${item.evidence_id}/inspect`);await refresh()}
      catch(cause){toast(errorMessage(cause),'warning')}
    }
    toast('整改资料已提交，请核对观察后复核。','success')
  } catch(cause){toast(errorMessage(cause),'error')}
  finally {busy.value=''}
}
async function verify(){
  if(!selected.value || !confirmed.value || busy.value)return
  busy.value='verify'
  try {
    const value=await api.post<CaseBundle>(`/cases/${current.value.case_id}/verify`,{after_evidence_ids:[selected.value.evidence_id],
      reviewer:form.reviewer,reviewer_confirmed:true,manual_checks_confirmed:manualConfirmed.value,as_of:form.as_of,expected_case_version:current.value.version})
    update(value);toast(value.case.status==='closed' ? '复核通过，检查已关闭。' : '复核未通过，请继续处理。',value.case.status==='closed' ? 'success' : 'warning')
  } catch(cause){toast(errorMessage(cause),'error')}
  finally {busy.value=''}
}
</script>
<template>
  <section class="card rectification-panel">
    <header class="rectification-heading"><ShieldCheck :size="20" /><h2>隐患整改与复核</h2><span class="badge tone-blue">{{ current.status==='approved' ? '待整改' : current.status==='rectifying' ? '整改中' : '待复核' }}</span></header>
    <div class="rectification-body">
      <div v-if="current.status==='approved'" class="rectification-fields"><label>整改责任主体<input v-model="form.owner" class="input" aria-label="整改责任主体" /></label><label>整改完成时刻<input class="input" type="datetime-local" :value="localDateTime(form.implemented_at)" aria-label="整改完成时刻" @change="form.implemented_at=isoDateTime(($event.target as HTMLInputElement).value)" /></label><label class="wide">整改情况<textarea v-model="form.comment" class="textarea" rows="2" aria-label="整改情况" /></label></div>
      <div v-else-if="current.implementation" class="rectification-record"><CheckCircle2 :size="17" /><span>{{ current.implementation.owner }} · {{ formatDateTime(current.implementation.implemented_at) }}</span><strong>整改已提交</strong></div>
      <form v-if="current.status==='approved' || !selected || file" class="rectification-upload" @submit.prevent="submit"><label class="rectification-file"><Upload :size="22" /><strong>{{ file?.name || '上传整改后照片或复核资料' }}</strong><input ref="fileInput" type="file" accept=".png,.jpg,.jpeg,.pdf" aria-label="上传整改复核资料" @change="fileChanged" /></label><div class="upload-action"><label>资料拍摄时刻<input class="input" type="datetime-local" :value="localDateTime(form.captured_at)" aria-label="整改资料拍摄时刻" @change="form.captured_at=isoDateTime(($event.target as HTMLInputElement).value)" /></label><button class="btn btn-primary" :disabled="!!busy || !file"><Loader2 v-if="busy" :size="16" class="spin" />{{ busy==='vision' ? '正在识别整改后资料' : '提交整改与证据' }}</button></div></form>
      <template v-if="selected"><div class="review-evidence"><img v-if="!selected.file_path?.endsWith('.pdf')" :src="selected.image_url || `/api/files/evidence/${selected.evidence_id}`" :alt="selected.label" /><div><h3>本次复核资料</h3><span>{{ formatDateTime(selected.captured_at) }}</span><small>{{ selected.evidence_id }}</small><label class="btn btn-sm">更换复核资料<input type="file" accept=".png,.jpg,.jpeg,.pdf" aria-label="更换复核资料" @change="fileChanged" /></label></div></div><EvidenceReview v-if="selected.source==='upload' && busy!=='vision'" :key="selected.evidence_id" :evidence="selected" :case-id="current.case_id" :version="current.version" :status="current.status" @saved="update" @refresh="refresh" /><div v-if="busy==='vision'" class="vision-pending"><Loader2 class="spin" :size="16" />正在识别整改后资料</div>
        <div v-if="current.status==='pending_verification'" class="verification-confirm"><div class="rectification-fields"><label>复核人<input v-model="form.reviewer" class="input" aria-label="复核人" /></label><label>复核时刻<input class="input" type="datetime-local" :value="localDateTime(form.as_of)" aria-label="复核时刻" @change="form.as_of=isoDateTime(($event.target as HTMLInputElement).value)" /></label></div><label v-if="required.length" class="manual-check"><input v-model="manualConfirmed" type="checkbox" />已逐项核验：{{ required.join('；') }}</label><button class="btn btn-primary verify-submit" :disabled="!!busy || !confirmed || (required.length>0 && !manualConfirmed)" @click="verify"><Loader2 v-if="busy==='verify'" class="spin" :size="16" /><ShieldCheck v-else :size="16" />确认资料并执行复核</button></div>
      </template>
    </div>
  </section>
</template>
<style scoped>
.rectification-heading{display:flex;align-items:center;gap:10px;padding:21px 24px;border-bottom:1px solid var(--line)}.rectification-heading>svg{color:var(--blue)}.rectification-heading h2{font-size:21px}.rectification-heading .badge{margin-left:auto}.rectification-body{padding:24px}.rectification-fields{display:grid;grid-template-columns:1fr 1fr;gap:16px}.rectification-fields label,.upload-action label{display:grid;gap:8px;font-size:14px;min-width:0}.rectification-fields .wide{grid-column:1/-1}.rectification-upload{margin-top:22px}.rectification-file{display:grid;justify-items:center;gap:12px;padding:25px;border:1px dashed #b6c9dd;border-radius:10px;background:#f8fafc;color:var(--blue)}.rectification-file strong{font-size:14px}.rectification-file input{font-size:12px;max-width:100%}.upload-action{display:flex;align-items:flex-end;justify-content:space-between;gap:18px;margin-top:16px}.upload-action label{flex:1}.rectification-record{display:flex;align-items:center;gap:9px;padding:14px;background:#f0f8f4;color:var(--green);border-radius:9px;font-size:13px;flex-wrap:wrap}.rectification-record strong{margin-left:auto;font-weight:500}.review-evidence{display:grid;grid-template-columns:180px 1fr;gap:20px;align-items:center;margin-top:20px}.review-evidence>img{width:100%;height:130px;object-fit:contain;border-radius:8px;background:#f1f5f9}.review-evidence>div{display:grid;gap:9px;justify-items:start}.review-evidence span,.review-evidence small{font-size:12px;color:var(--muted)}.review-evidence input{display:none}.verification-confirm{border-top:1px solid var(--line);padding-top:22px;margin-top:22px}.verify-submit{margin-top:20px;min-height:44px}.manual-check{display:flex;align-items:center;gap:8px;font-size:13px;margin-top:15px}.vision-pending{display:flex;gap:8px;color:var(--blue);font-size:13px;padding:18px 0}@media(max-width:650px){.rectification-body{padding:18px}.rectification-fields{grid-template-columns:1fr}.upload-action{flex-direction:column;align-items:stretch}.review-evidence{grid-template-columns:130px 1fr;gap:12px}.rectification-heading{padding:18px}.rectification-heading h2{font-size:19px}}
</style>
