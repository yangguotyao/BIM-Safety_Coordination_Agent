<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  CalendarClock,
  Check,
  CheckCircle2,
  ChevronRight,
  ClipboardCheck,
  Clock,
  Download,
  ExternalLink,
  FileJson,
  FileText,
  History,
  ImagePlus,
  Info,
  Loader2,
  Lock,
  MapPin,
  Play,
  Plus,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Upload,
  UserCheck,
  X,
  XCircle,
} from 'lucide-vue-next'
import EmptyState from '../components/EmptyState.vue'
import Modal from '../components/Modal.vue'
import StatusBadge from '../components/StatusBadge.vue'
import { api } from '../api'
import { errorMessage, refreshSummary, toast } from '../store'
import type { CaseBundle, CaseEvent, Evidence, Run, Rule } from '../types'
import {
  demoTime,
  eventLabel,
  formatDateTime,
  formatTime,
  resultLabel,
  shortGuid,
  statusLabel,
  statusTone,
  toneForResult,
} from '../utils'

const route = useRoute()
const router = useRouter()
const bundle = ref<CaseBundle | null>(null)
const loading = ref(true)
const busy = ref('')
const activeTab = ref('overview')
const runDetail = ref<Run | null>(null)
const allEvidence = ref<Evidence[]>([])
const evidenceModal = ref(false)
const selectedEvidenceIds = ref<string[]>([])
const uploadFile = ref<File | null>(null)
const uploadRef = ref<HTMLInputElement | null>(null)
const pollTimer = ref<number | undefined>(undefined)

const reviewForm = reactive({
  decision: 'approve',
  reviewer: '演示安全员',
  comment: '',
  reviewed_at: '',
  control_version: 0,
  newAction: '',
})
const implementForm = reactive({
  owner: '演示机电班组',
  implemented_at: '',
  comment: '模拟实施记录，不代表现场实际施工。',
})
const verifyForm = reactive({
  afterEvidenceIds: [] as string[],
  reviewer: '演示安全员',
  asOf: '',
  confirmed: true,
})
const reopenForm = reactive({
  reason: '新证据显示条件变化，需要重新检查。',
  evidenceIds: [] as string[],
})

const caseData = computed(() => bundle.value?.case || null)
const evidence = computed(() => bundle.value?.evidence || [])
const rules = computed(() => bundle.value?.rules || [])
const events = computed(() => bundle.value?.events || [])
const runs = computed(() => bundle.value?.runs || [])
const latestRun = computed<Run | null>(() => runDetail.value || runs.value[0] || null)
const finding = computed(() => caseData.value?.findings?.[0] || null)
const controls = computed(() => caseData.value?.controls || [])
const isAnalyzing = computed(() => caseData.value?.status === 'analyzing')
const canAnalyze = computed(() => ['draft', 'needs_evidence', 'reopened'].includes(caseData.value?.status || ''))
const canReview = computed(() => caseData.value?.status === 'pending_review')
const canImplement = computed(() => caseData.value?.status === 'approved')
const canVerify = computed(() => caseData.value?.status === 'pending_verification')
const canReopen = computed(() => caseData.value?.status === 'closed')
const afterEvidence = computed(() => evidence.value.filter((item) => item.stage === 'after'))
const availableEvidence = computed(() =>
  allEvidence.value.filter((item) => !(caseData.value?.evidence_ids || []).includes(item.evidence_id)),
)
const stepper = computed(() => {
  const status = caseData.value?.status || 'draft'
  const order = ['draft', 'analyzing', 'pending_review', 'approved', 'rectifying', 'pending_verification', 'closed']
  const label = ['草稿', '分析', '待审核', '已批准', '整改', '待复核', '已关闭']
  const active = order.indexOf(status)
  return order.map((key, index) => ({
    key,
    label: label[index],
    active: index === active,
    done: active >= 0 && index < active,
    branch: ['needs_evidence', 'reopened', 'rejected'].includes(status) && index === Math.max(1, active),
  }))
})
const branchNotice = computed(() => {
  const status = caseData.value?.status
  if (status === 'needs_evidence') return { tone: 'amber', text: '分析发现关键证据或字段不足，案例进入“待补证”；补齐后需重新分析，不能直接关闭。' }
  if (status === 'reopened') return { tone: 'rose', text: '案例已重新打开；此前的 closed / verification 事件保留，不会被覆盖。' }
  if (status === 'rejected') return { tone: 'red', text: '审核已拒绝该演示控制方案；案例不会进入整改或关闭。' }
  return null
})

async function load(silent = false) {
  if (!silent) loading.value = true
  try {
    const response = await api.get<CaseBundle>(`/cases/${route.params.id}`)
    bundle.value = response
    if (!reviewForm.reviewed_at) reviewForm.reviewed_at = demoTime(response.case.as_of, 10)
    if (!implementForm.implemented_at) implementForm.implemented_at = demoTime(response.case.as_of, 20)
    if (!verifyForm.asOf) verifyForm.asOf = demoTime(response.case.as_of, 40)
    reviewForm.control_version = response.case.control_version
    const latest = response.runs[0]
    if (latest) {
      try {
        const run = await api.get<{ run: Run }>(`/runs/${latest.run_id}`)
        runDetail.value = run.run
      } catch {
        runDetail.value = null
      }
    }
    if (response.case.status === 'analyzing') startPolling()
    else stopPolling()
  } catch (error: any) {
    toast(errorMessage(error), 'error')
  } finally {
    loading.value = false
  }
}

async function loadAllEvidence() {
  try {
    const response = await api.get<{ rows: Evidence[] }>('/evidence')
    allEvidence.value = response.rows
  } catch {
    allEvidence.value = []
  }
}

function startPolling() {
  if (pollTimer.value) return
  pollTimer.value = window.setInterval(() => load(true), 1500)
}

function stopPolling() {
  if (pollTimer.value) {
    window.clearInterval(pollTimer.value)
    pollTimer.value = undefined
  }
}

async function analyze() {
  if (!caseData.value || busy.value) return
  busy.value = 'analyze'
  try {
    await api.post(`/cases/${caseData.value.case_id}/analyze`)
    toast('分析已启动，Agent 正在写入实际 trace。', 'success')
    await load()
    activeTab.value = 'overview'
    await refreshSummary()
  } catch (error: any) {
    toast(errorMessage(error), 'error')
  } finally {
    busy.value = ''
  }
}

async function submitReview(decisionOverride?: string) {
  if (!caseData.value || busy.value) return
  const decision = decisionOverride || reviewForm.decision
  busy.value = 'review'
  try {
    const payload: any = {
      decision,
      reviewer: reviewForm.reviewer,
      comment: reviewForm.comment,
      reviewed_at: reviewForm.reviewed_at,
      control_version: reviewForm.control_version,
      expected_case_version: caseData.value.version,
    }
    if (decision === 'modify') {
      const current = controls.value[0]
      if (!reviewForm.newAction.trim()) {
        toast('请填写修改后的控制措施', 'warning')
        return
      }
      payload.new_controls = [
        {
          control_id: current?.control_id,
          finding_id: current?.finding_id || finding.value?.finding_id,
          action: reviewForm.newAction.trim(),
          owner: current?.owner || '演示机电班组',
          verification_requirements: current?.verification_requirements || [],
        },
      ]
    }
    const response = await api.post<CaseBundle>(`/cases/${caseData.value.case_id}/review`, payload)
    bundle.value = response
    toast(decision === 'approve' ? '已记录人工批准。' : decision === 'reject' ? '已记录拒绝。' : '控制措施已更新，等待重新审核。', 'success')
    await refreshSummary()
    if (decision === 'approve') activeTab.value = 'verify'
  } catch (error: any) {
    toast(errorMessage(error), 'error', 7000)
  } finally {
    busy.value = ''
  }
}

async function submitImplementation() {
  if (!caseData.value || busy.value) return
  busy.value = 'implement'
  try {
    const response = await api.post<CaseBundle>(`/cases/${caseData.value.case_id}/implementation`, {
      owner: implementForm.owner,
      implemented_at: implementForm.implemented_at,
      comment: implementForm.comment,
      expected_case_version: caseData.value.version,
    })
    bundle.value = response
    toast('已记录人工实施时刻与责任人；接下来提交实施后证据。', 'success')
    await refreshSummary()
    activeTab.value = 'verify'
  } catch (error: any) {
    toast(errorMessage(error), 'error', 7000)
  } finally {
    busy.value = ''
  }
}

async function addEvidence(ids: string[]) {
  if (!caseData.value || busy.value) return
  if (!ids.length) {
    toast('请选择至少一条证据', 'warning')
    return
  }
  busy.value = 'evidence'
  try {
    const response = await api.post<CaseBundle>(`/cases/${caseData.value.case_id}/evidence`, {
      evidence_ids: ids,
      actor: '演示安全员',
    })
    bundle.value = response
    selectedEvidenceIds.value = []
    evidenceModal.value = false
    toast('证据已追加到案例。', 'success')
  } catch (error: any) {
    toast(errorMessage(error), 'error', 7000)
  } finally {
    busy.value = ''
  }
}

async function uploadEvidence() {
  if (!caseData.value || !uploadFile.value || busy.value) return
  busy.value = 'upload'
  try {
    const data = new FormData()
    data.append('file', uploadFile.value)
    data.append('captured_at', demoTime(caseData.value.as_of, 30))
    data.append('stage', 'after')
    data.append('note', uploadFile.value.name)
    const response = await api.postForm<CaseBundle>(`/cases/${caseData.value.case_id}/evidence/upload`, data)
    bundle.value = response
    uploadFile.value = null
    if (uploadRef.value) uploadRef.value.value = ''
    evidenceModal.value = false
    toast('文件已保存；未做视觉识别，关键字段为 unknown。', 'warning', 6000)
  } catch (error: any) {
    toast(errorMessage(error), 'error', 7000)
  } finally {
    busy.value = ''
  }
}

async function submitVerify() {
  if (!caseData.value || busy.value) return
  if (!verifyForm.afterEvidenceIds.length) {
    toast('请选择至少一条实施后证据', 'warning')
    return
  }
  busy.value = 'verify'
  try {
    const response = await api.post<CaseBundle>(`/cases/${caseData.value.case_id}/verify`, {
      after_evidence_ids: verifyForm.afterEvidenceIds,
      reviewer: verifyForm.reviewer,
      reviewer_confirmed: verifyForm.confirmed,
      as_of: verifyForm.asOf,
      expected_case_version: caseData.value.version,
    })
    bundle.value = response
    const result = response.case.verification?.result
    toast(result === 'pass_in_demo_scope' ? '复核通过，案例已关闭（仅限演示范围）。' : '复核未通过，案例已重新打开并保留残余风险。', result === 'pass_in_demo_scope' ? 'success' : 'warning', 7000)
    await refreshSummary()
    activeTab.value = 'verify'
  } catch (error: any) {
    toast(errorMessage(error), 'error', 8000)
  } finally {
    busy.value = ''
  }
}

async function submitReopen() {
  if (!caseData.value || busy.value) return
  if (!reopenForm.evidenceIds.length) {
    toast('请选择条件变化的新证据', 'warning')
    return
  }
  busy.value = 'reopen'
  try {
    const response = await api.post<CaseBundle>(`/cases/${caseData.value.case_id}/reopen`, {
      reason: reopenForm.reason,
      evidence_ids: reopenForm.evidenceIds,
      actor: '演示安全员',
    })
    bundle.value = response
    toast('案例已重新打开，closed 事件保留。', 'success')
    await refreshSummary()
    activeTab.value = 'overview'
  } catch (error: any) {
    toast(errorMessage(error), 'error', 7000)
  } finally {
    busy.value = ''
  }
}

async function exportCase(format: 'json' | 'md') {
  if (!caseData.value) return
  try {
    await api.download(`/cases/${caseData.value.case_id}/export?format=${format}`, `${caseData.value.case_id}.${format}`)
    toast('导出已开始。', 'success')
  } catch (error: any) {
    toast(errorMessage(error), 'error')
  }
}

function toggleVerifyEvidence(id: string) {
  if (verifyForm.afterEvidenceIds.includes(id)) {
    verifyForm.afterEvidenceIds = verifyForm.afterEvidenceIds.filter((item) => item !== id)
  } else {
    verifyForm.afterEvidenceIds = [...verifyForm.afterEvidenceIds, id]
  }
}

function toggleReopenEvidence(id: string) {
  if (reopenForm.evidenceIds.includes(id)) {
    reopenForm.evidenceIds = reopenForm.evidenceIds.filter((item) => item !== id)
  } else {
    reopenForm.evidenceIds = [...reopenForm.evidenceIds, id]
  }
}

function toggleSelectedEvidence(id: string) {
  if (selectedEvidenceIds.value.includes(id)) {
    selectedEvidenceIds.value = selectedEvidenceIds.value.filter((item) => item !== id)
  } else {
    selectedEvidenceIds.value = [...selectedEvidenceIds.value, id]
  }
}

function onUploadChange(event: Event) {
  const target = event.target as HTMLInputElement
  uploadFile.value = target.files?.[0] || null
}

function openBim(evidenceId: string) {
  router.push({ path: '/bim', query: { evidence: evidenceId } })
}

function checkTone(result: string) {
  if (result === 'pass') return 'tone-green'
  if (result === 'fail') return 'tone-red'
  return 'tone-amber'
}

watch(
  () => route.params.id,
  () => {
    stopPolling()
    load()
    loadAllEvidence()
  },
)

onMounted(() => {
  load()
  loadAllEvidence()
})
onBeforeUnmount(stopPolling)
</script>

<template>
  <div class="page detail-page">
    <div v-if="loading" class="card loading-block">
      <Loader2 :size="18" class="spin" />
      <span>读取 Safety Case…</span>
    </div>

    <template v-else-if="caseData">
      <div class="detail-head">
        <div class="detail-title-wrap">
          <router-link class="back-link" to="/cases"><ArrowLeft :size="13" /> 返回案例列表</router-link>
          <div class="title-row">
            <h1>{{ caseData.title }}</h1>
            <StatusBadge :status="caseData.status" dot />
          </div>
          <div class="detail-meta">
            <span class="mono">{{ caseData.case_id }}</span>
            <span class="sep">·</span>
            <span>v{{ caseData.version }}</span>
            <span class="sep">·</span>
            <span><CalendarClock :size="12" /> {{ formatDateTime(caseData.as_of) }}</span>
            <span class="sep">·</span>
            <span class="mono">{{ caseData.model_id }} @ {{ caseData.model_version }}</span>
            <span class="sep">·</span>
            <span>{{ caseData.zone_id }}</span>
          </div>
        </div>
        <div class="head-actions">
          <button class="btn btn-sm" @click="load()"><RefreshCw :size="13" /> 刷新</button>
          <button class="btn btn-sm" @click="exportCase('json')"><FileJson :size="13" /> JSON</button>
          <button class="btn btn-sm" @click="exportCase('md')"><FileText :size="13" /> Markdown</button>
          <button v-if="canAnalyze" class="btn btn-sm btn-primary" :disabled="busy === 'analyze'" @click="analyze">
            <Loader2 v-if="busy === 'analyze'" :size="13" class="spin" />
            <Play v-else :size="13" />
            {{ caseData.status === 'draft' ? '开始分析' : '重新分析' }}
          </button>
        </div>
      </div>

      <div class="stepper card">
        <div v-for="(step, index) in stepper" :key="step.key" class="step" :class="{ active: step.active, done: step.done, branch: step.branch }">
          <div class="step-dot">
            <Check v-if="step.done" :size="10" />
            <span v-else>{{ index + 1 }}</span>
          </div>
          <span class="step-label">{{ step.label }}</span>
          <ChevronRight v-if="index < stepper.length - 1" :size="12" class="step-arrow" />
        </div>
      </div>

      <div v-if="branchNotice" class="branch-banner" :class="`branch-${branchNotice.tone}`">
        <AlertTriangle :size="14" />
        <span>{{ branchNotice.text }}</span>
      </div>

      <div v-if="isAnalyzing" class="analyzing-banner">
        <Loader2 :size="15" class="spin" />
        <div>
          <strong>Agent 正在执行六类职责节点</strong>
          <div class="small muted">实际工具调用与输出写入 agent_events；页面每 1.5 秒轮询一次。</div>
        </div>
        <router-link class="btn btn-sm" :to="`/agent?case=${caseData.case_id}`">查看实时 trace <ArrowRight :size="12" /></router-link>
      </div>

      <div class="detail-grid">
        <div class="detail-main">
          <div class="tabs card">
            <button class="tab" :class="{ active: activeTab === 'overview' }" @click="activeTab = 'overview'">概览</button>
            <button class="tab" :class="{ active: activeTab === 'evidence' }" @click="activeTab = 'evidence'">
              证据 <span class="tab-count">{{ evidence.length }}</span>
            </button>
            <button class="tab" :class="{ active: activeTab === 'review' }" @click="activeTab = 'review'">
              审核与措施 <span v-if="canReview" class="tab-alert" />
            </button>
            <button class="tab" :class="{ active: activeTab === 'verify' }" @click="activeTab = 'verify'">实施与复核</button>
            <button class="tab" :class="{ active: activeTab === 'events' }" @click="activeTab = 'events'">
              事件 <span class="tab-count">{{ events.length }}</span>
            </button>
          </div>

          <div v-if="activeTab === 'overview'" class="tab-panel">
            <div v-if="finding" class="card finding-card">
              <div class="card-head">
                <div class="card-title">
                  <AlertTriangle :size="15" />
                  Finding · {{ finding.finding_id }}
                </div>
                <span class="badge" :class="`tone-${toneForResult(finding.result)}`">{{ resultLabel(finding.result) }}</span>
              </div>
              <div class="card-body">
                <div class="finding-hero">
                  <div>
                    <h2>{{ finding.hazard }}</h2>
                    <div class="finding-tags">
                      <span class="badge tone-slate">{{ finding.risk_level || '未判定风险等级' }}</span>
                      <span class="badge tone-amber">演示策略</span>
                      <span class="badge tone-cyan">{{ finding.evidence_ids?.join(' · ') }}</span>
                    </div>
                  </div>
                  <div class="finding-rule-list">
                    <span class="caption">GOVERNING RULES</span>
                    <router-link v-for="ruleId in finding.rule_ids" :key="ruleId" class="rule-pill mono" :to="`/knowledge?rule=${ruleId}`">
                      {{ ruleId }} <ExternalLink :size="10" />
                    </router-link>
                  </div>
                </div>

                <div v-if="finding.narrative" class="narrative-block">
                  <div class="narrative-head">
                    <Sparkles :size="13" />
                    <span>{{ finding.narrative.label || 'Agent 归纳' }}</span>
                    <span class="badge tone-violet">只归纳，不计算</span>
                  </div>
                  <p>{{ finding.narrative.summary }}</p>
                  <div v-if="finding.narrative.reasoning_basis?.length" class="narrative-basis">
                    <span class="caption">BASIS</span>
                    <span v-for="basis in finding.narrative.reasoning_basis" :key="`${basis.type}-${basis.id}`" class="mono">{{ basis.type }}:{{ basis.id }}</span>
                  </div>
                </div>

                <div class="check-grid">
                  <div v-for="check in finding.checks" :key="check.name" class="check-item">
                    <span class="check-icon" :class="checkTone(check.result)">
                      <CheckCircle2 v-if="check.result === 'pass'" :size="12" />
                      <XCircle v-else-if="check.result === 'fail'" :size="12" />
                      <Info v-else :size="12" />
                    </span>
                    <div>
                      <div class="check-name">{{ check.name }}</div>
                      <div class="check-source">{{ check.source }}</div>
                      <div v-if="check.note" class="check-note">{{ check.note }}</div>
                    </div>
                  </div>
                </div>

                <div v-if="finding.uncertainties?.length" class="uncertainties">
                  <div class="caption" style="margin-bottom: 6px">UNCERTAINTIES / 边界</div>
                  <ul>
                    <li v-for="item in finding.uncertainties" :key="item">{{ item }}</li>
                  </ul>
                </div>
              </div>
            </div>

            <div v-else class="card">
              <EmptyState title="尚未形成 Finding" detail="点击“开始分析”，让 Agent 读取真实构件、匹配证据与 active 条款。">
                <button v-if="canAnalyze" class="btn btn-primary btn-sm" style="margin-top: 8px" @click="analyze">开始分析</button>
              </EmptyState>
            </div>

            <div class="card controls-card">
              <div class="card-head">
                <div class="card-title"><ShieldCheck :size="15" /> 控制措施 <span class="badge tone-slate">v{{ caseData.control_version }}</span></div>
                <span class="badge" :class="caseData.review ? `tone-${caseData.review.decision === 'approve' ? 'green' : caseData.review.decision === 'reject' ? 'red' : 'violet'}` : 'tone-slate'">
                  {{ caseData.review ? (caseData.review.decision === 'approve' ? '已批准' : caseData.review.decision === 'reject' ? '已拒绝' : '已修改') : '待审核' }}
                </span>
              </div>
              <div class="card-body">
                <div v-if="controls.length" class="control-list">
                  <div v-for="control in controls" :key="control.control_id" class="control-item">
                    <div class="control-top">
                      <span class="mono">{{ control.control_id }} · v{{ control.version }}</span>
                      <span class="badge tone-slate">{{ control.status }}</span>
                    </div>
                    <p>{{ control.action }}</p>
                    <div class="control-meta">
                      <span><UserCheck :size="12" /> {{ control.owner }}</span>
                      <span><ClipboardCheck :size="12" /> {{ control.verification_requirements?.length || 0 }} 项验证要求</span>
                    </div>
                    <ul v-if="control.verification_requirements?.length" class="req-list">
                      <li v-for="req in control.verification_requirements" :key="req">{{ req }}</li>
                    </ul>
                  </div>
                </div>
                <EmptyState v-else title="没有控制措施" detail="正常样例无需整改；若为风险候选，分析会生成待人工审核的候选措施。" />
              </div>
            </div>

            <div class="overview-bottom">
              <section class="card">
                <div class="card-head"><div class="card-title"><Info :size="15" /> 数据性质与假设</div></div>
                <div class="card-body">
                  <div class="kv">
                    <span class="k">项目</span><span class="v">{{ caseData.project_id }}</span>
                    <span class="k">区域</span><span class="v mono">{{ caseData.zone_id }}</span>
                    <span class="k">任务</span><span class="v mono">{{ caseData.task_id }}</span>
                    <span class="k">provenance</span><span class="v mono">{{ caseData.provenance }}</span>
                    <span class="k">模式</span><span class="v">{{ caseData.mode === 'demo' ? '演示模式（确定性模板）' : '真实模型模式' }}</span>
                  </div>
                  <ul class="assumption-list">
                    <li v-for="item in caseData.assumptions" :key="item">{{ item }}</li>
                  </ul>
                </div>
              </section>
              <section class="card">
                <div class="card-head"><div class="card-title"><History :size="15" /> 状态与版本</div></div>
                <div class="card-body">
                  <div class="kv">
                    <span class="k">状态</span><span class="v">{{ statusLabel(caseData.status) }}</span>
                    <span class="k">案例版本</span><span class="v mono">v{{ caseData.version }}</span>
                    <span class="k">控制版本</span><span class="v mono">v{{ caseData.control_version }}</span>
                    <span class="k">最近 run</span><span class="v mono">{{ caseData.last_run_id || '—' }}</span>
                    <span class="k">分析完整</span>
                    <span class="v">{{ caseData.analysis_incomplete ? '否 · 需补证' : '是' }}</span>
                  </div>
                  <div class="notice" style="margin-top: 12px">
                    <Lock :size="13" />
                    <span>未经人工批准不会进入整改；未提交实施后证据与人工确认不会关闭。</span>
                  </div>
                </div>
              </section>
            </div>
          </div>

          <div v-else-if="activeTab === 'evidence'" class="tab-panel">
            <div class="card">
              <div class="card-head">
                <div class="card-title"><ImagePlus :size="15" /> 案例证据链 <span class="badge tone-slate">{{ evidence.length }}</span></div>
                <div class="row">
                  <button class="btn btn-sm" @click="evidenceModal = true"><Upload :size="13" /> 补证 / 上传</button>
                  <button v-if="canAnalyze" class="btn btn-sm btn-primary" :disabled="busy === 'analyze'" @click="analyze">
                    <RefreshCw :size="13" /> 重新分析
                  </button>
                </div>
              </div>
              <div class="card-body">
                <div v-if="evidence.length" class="evidence-grid">
                  <article v-for="item in evidence" :key="item.evidence_id" class="evidence-card">
                    <div class="evidence-img-wrap" @click="openBim(item.evidence_id)">
                      <img :src="item.image_url" :alt="item.label" />
                    </div>
                    <div class="evidence-body">
                      <div class="row" style="justify-content: space-between">
                        <span class="mono small">{{ item.evidence_id }}</span>
                        <span class="badge" :class="item.stage === 'after' ? 'tone-teal' : 'tone-cyan'">{{ item.stage === 'after' ? '实施后' : '检查时' }}</span>
                      </div>
                      <strong>{{ item.label }}</strong>
                      <div class="demo-flag"><span class="badge tone-amber">演示示意图 · 非现场照片</span></div>
                      <div class="tiny dim">{{ formatDateTime(item.captured_at) }}</div>
                      <div class="obs-list">
                        <span v-for="key in ['guardrail_state', 'guardrail_height_m', 'worker_present', 'drop_height_m']" :key="key" class="chip">
                          <span class="k">{{ key }}</span>
                          <span class="mono">{{ item.observation[key] === null ? 'unknown' : String(item.observation[key]) }}</span>
                        </span>
                      </div>
                      <div class="evidence-actions">
                        <button class="btn btn-sm" @click="openBim(item.evidence_id)"><MapPin :size="12" /> BIM 定位</button>
                        <span class="tiny dim">{{ item.provenance }}</span>
                      </div>
                    </div>
                  </article>
                </div>
                <EmptyState v-else title="没有证据" detail="选择包内 12 条证据之一，或上传 PNG/JPG/PDF。" />
              </div>
            </div>
          </div>

          <div v-else-if="activeTab === 'review'" class="tab-panel">
            <div v-if="canReview" class="card">
              <div class="card-head">
                <div class="card-title"><BadgeCheck :size="15" /> 人工审核</div>
                <span class="badge tone-violet">等待演示安全员</span>
              </div>
              <div class="card-body">
                <div class="decision-grid">
                  <button class="decision" :class="{ active: reviewForm.decision === 'approve' }" @click="reviewForm.decision = 'approve'">
                    <CheckCircle2 :size="17" />
                    <strong>批准</strong>
                    <span>进入演示实施</span>
                  </button>
                  <button class="decision" :class="{ active: reviewForm.decision === 'modify' }" @click="reviewForm.decision = 'modify'">
                    <RefreshCw :size="17" />
                    <strong>修改措施</strong>
                    <span>新版本重新审核</span>
                  </button>
                  <button class="decision danger" :class="{ active: reviewForm.decision === 'reject' }" @click="reviewForm.decision = 'reject'">
                    <XCircle :size="17" />
                    <strong>拒绝</strong>
                    <span>不进入整改</span>
                  </button>
                </div>
                <div class="form-row" style="margin-top: 16px">
                  <div class="field">
                    <label>审核人（演示身份）</label>
                    <input v-model="reviewForm.reviewer" class="input" />
                  </div>
                  <div class="field">
                    <label>审核时刻</label>
                    <input v-model="reviewForm.reviewed_at" class="input mono" />
                  </div>
                </div>
                <div v-if="reviewForm.decision === 'modify'" class="field" style="margin-top: 14px">
                  <label>修改后的控制措施</label>
                  <textarea v-model="reviewForm.newAction" class="textarea" placeholder="描述修改后的措施；提交后控制版本 +1，必须重新审核。" />
                </div>
                <div class="field" style="margin-top: 14px">
                  <label>审核意见</label>
                  <textarea v-model="reviewForm.comment" class="textarea" placeholder="记录批准范围、限制条件或拒绝理由。" />
                </div>
                <div class="notice" style="margin-top: 13px">
                  <Lock :size="13" />
                  <span>
                    控制版本 v{{ caseData.control_version }} · 案例版本 v{{ caseData.version }}。旧页面不能覆盖新审批；版本冲突返回 409。
                  </span>
                </div>
                <div class="form-actions">
                  <button class="btn" :disabled="busy === 'review'" @click="submitReview('reject')">拒绝</button>
                  <button class="btn" :disabled="busy === 'review'" @click="submitReview('modify')">提交修改</button>
                  <button class="btn btn-primary" :disabled="busy === 'review'" @click="submitReview('approve')">
                    <Loader2 v-if="busy === 'review'" :size="14" class="spin" />
                    <Check v-else :size="14" />
                    批准控制措施
                  </button>
                </div>
              </div>
            </div>
            <div v-else class="card">
              <div class="card-head"><div class="card-title"><BadgeCheck :size="15" /> 审核记录</div></div>
              <div class="card-body">
                <div v-if="caseData.review" class="review-record">
                  <div class="row" style="justify-content: space-between">
                    <span class="badge" :class="caseData.review.decision === 'approve' ? 'tone-green' : caseData.review.decision === 'reject' ? 'tone-red' : 'tone-violet'">
                      {{ caseData.review.decision === 'approve' ? '已批准' : caseData.review.decision === 'reject' ? '已拒绝' : '已修改' }}
                    </span>
                    <span class="mono small dim">控制 v{{ caseData.review.control_version }}</span>
                  </div>
                  <p style="margin-top: 12px">{{ caseData.review.comment }}</p>
                  <div class="review-meta">
                    <span><UserCheck :size="12" /> {{ caseData.review.reviewer }}</span>
                    <span><Clock :size="12" /> {{ formatDateTime(caseData.review.reviewed_at) }}</span>
                  </div>
                </div>
                <EmptyState v-else title="尚未审核" detail="案例进入 pending_review 后，演示安全员可批准、拒绝或修改。" />
              </div>
            </div>
          </div>

          <div v-else-if="activeTab === 'verify'" class="tab-panel">
            <div v-if="canImplement" class="card">
              <div class="card-head"><div class="card-title"><ShieldCheck :size="15" /> 记录人工实施</div><span class="badge tone-blue">approved</span></div>
              <div class="card-body">
                <div class="form-row">
                  <div class="field">
                    <label>实施责任人（演示班组）</label>
                    <input v-model="implementForm.owner" class="input" />
                  </div>
                  <div class="field">
                    <label>实施时刻</label>
                    <input v-model="implementForm.implemented_at" class="input mono" />
                  </div>
                </div>
                <div class="field" style="margin-top: 14px">
                  <label>实施说明</label>
                  <textarea v-model="implementForm.comment" class="textarea" />
                </div>
                <div class="notice warn" style="margin-top: 13px">
                  <AlertTriangle :size="13" />
                  <span>这只是模拟实施记录，不代表现场实际施工；不会自动生成现场完成状态。</span>
                </div>
                <div class="form-actions">
                  <button class="btn btn-primary" :disabled="busy === 'implement'" @click="submitImplementation">
                    <Loader2 v-if="busy === 'implement'" :size="14" class="spin" />
                    <Check v-else :size="14" />
                    记录实施并进入整改
                  </button>
                </div>
              </div>
            </div>

            <div v-else-if="caseData.status === 'rectifying'" class="card">
              <div class="card-head">
                <div class="card-title"><ImagePlus :size="15" /> 等待实施后证据</div>
                <span class="badge tone-orange">rectifying</span>
              </div>
              <div class="card-body">
                <div v-if="caseData.implementation" class="implementation-record">
                  <div class="record-icon"><ShieldCheck :size="16" /></div>
                  <div>
                    <div class="strong">已由 {{ caseData.implementation.owner }} 记录实施</div>
                    <div class="small muted">{{ formatDateTime(caseData.implementation.implemented_at) }} · {{ caseData.implementation.comment }}</div>
                  </div>
                </div>
                <div class="notice warn" style="margin-top: 13px">
                  <ImagePlus :size="13" />
                  <span>整改中。请追加一条晚于实施时刻的 after 证据（如 EV-006、EV-010），系统才会进入“待复核”。</span>
                  <button class="btn btn-sm" @click="evidenceModal = true">补交证据</button>
                </div>
              </div>
            </div>

            <div v-else-if="canVerify" class="card">
              <div class="card-head">
                <div class="card-title"><ClipboardCheck :size="15" /> 提交实施后证据并复核</div>
                <span class="badge tone-teal">待复核</span>
              </div>
              <div class="card-body">
                <div v-if="caseData.implementation" class="implementation-record">
                  <div class="record-icon"><ShieldCheck :size="16" /></div>
                  <div>
                    <div class="strong">已由 {{ caseData.implementation.owner }} 记录实施</div>
                    <div class="small muted">{{ formatDateTime(caseData.implementation.implemented_at) }} · {{ caseData.implementation.comment }}</div>
                  </div>
                </div>
                <div v-if="!afterEvidence.length" class="notice warn" style="margin: 12px 0">
                  <ImagePlus :size="13" />
                  <span>还没有实施后证据。请先通过“补证 / 上传”加入 EV-006、EV-010 等 after 证据。</span>
                  <button class="btn btn-sm" @click="evidenceModal = true">补证</button>
                </div>
                <div class="field" style="margin-top: 14px">
                  <label>选择实施后证据</label>
                  <div class="verify-evidence-list">
                    <button
                      v-for="item in evidence"
                      :key="item.evidence_id"
                      class="verify-evidence"
                      :class="{ selected: verifyForm.afterEvidenceIds.includes(item.evidence_id) }"
                      :disabled="item.stage !== 'after'"
                      @click="toggleVerifyEvidence(item.evidence_id)"
                    >
                      <img :src="item.image_url" :alt="item.label" />
                      <div>
                        <div class="mono small">{{ item.evidence_id }}</div>
                        <div class="tiny">{{ item.label }}</div>
                        <div class="tiny dim">{{ item.stage }} · {{ formatDateTime(item.captured_at) }}</div>
                      </div>
                      <Check v-if="verifyForm.afterEvidenceIds.includes(item.evidence_id)" :size="14" class="check" />
                    </button>
                  </div>
                </div>
                <div class="form-row" style="margin-top: 14px">
                  <div class="field">
                    <label>复核人</label>
                    <input v-model="verifyForm.reviewer" class="input" />
                  </div>
                  <div class="field">
                    <label>复核时刻</label>
                    <input v-model="verifyForm.asOf" class="input mono" />
                  </div>
                </div>
                <label class="confirm-line">
                  <input v-model="verifyForm.confirmed" type="checkbox" />
                  <span>演示安全员确认：已核对证据时间、区域、构件与防护检查项。</span>
                </label>
                <div class="form-actions">
                  <button class="btn btn-primary" :disabled="busy === 'verify'" @click="submitVerify">
                    <Loader2 v-if="busy === 'verify'" :size="14" class="spin" />
                    <ClipboardCheck v-else :size="14" />
                    执行复核
                  </button>
                </div>
              </div>
            </div>

            <div v-else-if="caseData.verification" class="card">
              <div class="card-head">
                <div class="card-title"><ClipboardCheck :size="15" /> 复核结果</div>
                <span class="badge" :class="caseData.verification.result === 'pass_in_demo_scope' ? 'tone-green' : 'tone-red'">
                  {{ caseData.verification.result === 'pass_in_demo_scope' ? '通过（演示范围）' : '未通过' }}
                </span>
              </div>
              <div class="card-body">
                <div class="verify-head">
                  <div class="verify-big" :class="caseData.verification.result === 'pass_in_demo_scope' ? 'ok' : 'fail'">
                    <CheckCircle2 v-if="caseData.verification.result === 'pass_in_demo_scope'" :size="25" />
                    <XCircle v-else :size="25" />
                  </div>
                  <div>
                    <h2>{{ caseData.verification.result === 'pass_in_demo_scope' ? '案例已关闭' : '案例已重新打开' }}</h2>
                    <p class="small muted">{{ caseData.verification.remaining_risk }}</p>
                  </div>
                </div>
                <div class="verify-checks">
                  <div v-for="check in caseData.verification.checks" :key="check.name" class="verify-check">
                    <span class="badge" :class="checkTone(check.result)">{{ check.result }}</span>
                    <span>{{ check.name }}</span>
                    <span class="tiny dim">{{ check.source }}</span>
                  </div>
                </div>
                <div v-if="canReopen" class="reopen-box">
                  <div class="section-title">CONDITION CHANGED / 重新打开</div>
                  <div class="field" style="margin-top: 10px">
                    <label>条件变化说明</label>
                    <textarea v-model="reopenForm.reason" class="textarea" />
                  </div>
                  <div class="field" style="margin-top: 10px">
                    <label>选择新证据</label>
                    <div class="verify-evidence-list">
                      <button
                        v-for="item in availableEvidence"
                        :key="item.evidence_id"
                        class="verify-evidence"
                        :class="{ selected: reopenForm.evidenceIds.includes(item.evidence_id) }"
                        @click="toggleReopenEvidence(item.evidence_id)"
                      >
                        <img :src="item.image_url" :alt="item.label" />
                        <div>
                          <div class="mono small">{{ item.evidence_id }}</div>
                          <div class="tiny">{{ item.label }}</div>
                        </div>
                        <Check v-if="reopenForm.evidenceIds.includes(item.evidence_id)" :size="14" class="check" />
                      </button>
                    </div>
                  </div>
                  <button class="btn btn-danger" style="margin-top: 12px" :disabled="busy === 'reopen'" @click="submitReopen">
                    <RotateCcw :size="13" /> 保留历史并重新打开
                  </button>
                </div>
              </div>
            </div>

            <div v-else-if="caseData.status === 'closed'" class="card">
              <div class="card-head"><div class="card-title"><CheckCircle2 :size="15" /> 无需整改的关闭案例</div><span class="badge tone-green">closed</span></div>
              <div class="card-body">
                <p class="small muted">
                  本次已检查项未发现防护缺失或高度不足；人工审核后直接关闭，因此没有实施与复核记录。该结论不代表整个现场安全。
                </p>
              </div>
            </div>

            <div v-else class="card">
              <EmptyState title="尚未进入实施与复核" detail="先完成分析并人工批准控制措施；实施后证据和复核结果会显示在这里。" />
            </div>
          </div>

          <div v-else-if="activeTab === 'events'" class="tab-panel">
            <div class="card">
              <div class="card-head"><div class="card-title"><History :size="15" /> 事件日志</div><span class="badge tone-slate">{{ events.length }} events</span></div>
              <div class="card-body">
                <div class="timeline">
                  <div v-for="event in events" :key="event.id" class="timeline-item">
                    <div class="timeline-dot" :class="`tone-${statusTone(event.status)}`" />
                    <div class="timeline-body">
                      <div class="timeline-top">
                        <strong>{{ eventLabel(event.event) }}</strong>
                        <span class="badge" :class="`tone-${statusTone(event.status)}`">{{ statusLabel(event.status) }}</span>
                        <span class="mono tiny dim" style="margin-left: auto">{{ formatDateTime(event.at) }}</span>
                      </div>
                      <div class="small muted">{{ event.actor }} · {{ event.provenance }}</div>
                      <details v-if="Object.keys(event.detail || {}).length" class="event-detail">
                        <summary>查看详情</summary>
                        <pre>{{ JSON.stringify(event.detail, null, 2) }}</pre>
                      </details>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <aside class="detail-rail">
          <div class="card trace-rail">
            <div class="card-head">
              <div class="card-title"><Sparkles :size="15" /> Agent 实际记录</div>
              <span class="badge" :class="latestRun?.status === 'failed' ? 'tone-red' : latestRun?.status === 'running' ? 'tone-cyan' : 'tone-green'">
                {{ latestRun?.status || 'no run' }}
              </span>
            </div>
            <div class="card-body">
              <template v-if="latestRun">
                <div class="run-meta">
                  <span class="mono tiny">{{ latestRun.run_id }}</span>
                  <span class="tiny dim">{{ latestRun.events?.length || 0 }} events</span>
                </div>
                <div class="trace-mini">
                  <div v-for="event in (latestRun.events || []).slice(0, 7)" :key="event.seq" class="trace-mini-item">
                    <span class="trace-seq mono">{{ String(event.seq).padStart(2, '0') }}</span>
                    <div>
                      <div class="trace-node">{{ event.node }}</div>
                      <div class="tiny dim">{{ event.tool || 'state' }} · {{ event.status }}</div>
                    </div>
                  </div>
                </div>
                <router-link class="btn btn-sm" style="width: 100%; margin-top: 10px" :to="`/agent?run=${latestRun.run_id}`">
                  打开完整 trace <ArrowRight :size="12" />
                </router-link>
              </template>
              <EmptyState v-else title="还没有 run" detail="分析后这里会显示节点、工具与状态。" />
            </div>
          </div>

          <div class="card rail-card">
            <div class="card-head"><div class="card-title"><Info :size="15" /> 演示边界</div></div>
            <div class="card-body">
              <ul class="rail-list">
                <li>真实：S1 板 / 墙几何、GUID、1,247 构件索引。</li>
                <li>模拟：人员、防护、活动、2.5 m 坠落高度。</li>
                <li>演示：1.2 m 高度检查、1.0 m 暴露阈值。</li>
                <li>不宣称：现场合规、事故概率、完整模型全量。</li>
              </ul>
              <router-link class="small" to="/about" style="display: inline-flex; align-items: center; gap: 4px; margin-top: 10px">
                阅读完整方法与边界 <ArrowUpRight :size="12" />
              </router-link>
            </div>
          </div>
        </aside>
      </div>
    </template>

    <Modal :open="evidenceModal" title="补证 / 上传" subtitle="追加包内证据，或上传 PNG/JPG/PDF（≤20MB）。上传件不做视觉识别。" width="760px" @close="evidenceModal = false">
      <div class="section-title">包内证据 · 未加入当前案例</div>
      <div v-if="availableEvidence.length" class="add-evidence-list">
        <button
          v-for="item in availableEvidence"
          :key="item.evidence_id"
          class="add-evidence"
          :class="{ selected: selectedEvidenceIds.includes(item.evidence_id) }"
          @click="toggleSelectedEvidence(item.evidence_id)"
        >
          <img :src="item.image_url" :alt="item.label" />
          <div>
            <div class="mono small">{{ item.evidence_id }}</div>
            <div class="small">{{ item.label }}</div>
            <div class="tiny dim">{{ item.stage }} · {{ formatDateTime(item.captured_at) }}</div>
          </div>
          <Check v-if="selectedEvidenceIds.includes(item.evidence_id)" :size="14" class="check" />
        </button>
      </div>
      <div v-else class="small dim" style="padding: 12px 0">包内 12 条证据都已加入当前案例；也可以上传新文件。</div>

      <div class="divider" />
      <div class="section-title">上传文件</div>
      <div class="upload-box">
        <input ref="uploadRef" type="file" accept=".png,.jpg,.jpeg,.pdf" @change="onUploadChange" />
        <div class="small dim">支持 PNG/JPG/PDF，单文件 ≤20MB；保存到 runtime/uploads，不接收任意本机路径。</div>
      </div>

      <template #footer>
        <button class="btn" @click="evidenceModal = false">取消</button>
        <button class="btn" :disabled="!selectedEvidenceIds.length || busy === 'evidence'" @click="addEvidence(selectedEvidenceIds)">
          <Loader2 v-if="busy === 'evidence'" :size="13" class="spin" />
          <Plus :size="13" />
          追加所选证据
        </button>
        <button class="btn btn-primary" :disabled="!uploadFile || busy === 'upload'" @click="uploadEvidence">
          <Loader2 v-if="busy === 'upload'" :size="13" class="spin" />
          <Upload v-else :size="13" />
          上传文件
        </button>
      </template>
    </Modal>
  </div>
</template>

<style scoped>
.detail-page {
  max-width: 1780px;
}
.loading-block {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 9px;
  padding: 60px;
  color: var(--muted);
}
.detail-head {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  gap: 20px;
  margin-bottom: 16px;
}
.back-link {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 10.5px;
  color: var(--dim);
  margin-bottom: 8px;
}
.back-link:hover {
  color: var(--teal);
}
.title-row {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}
.title-row h1 {
  font-size: 27px;
}
.detail-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 8px;
  font-size: 10.5px;
  color: var(--dim);
  flex-wrap: wrap;
}
.detail-meta span {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.sep {
  color: #33475c;
}
.stepper {
  display: flex;
  align-items: center;
  padding: 13px 16px;
  gap: 3px;
  overflow-x: auto;
  margin-bottom: 12px;
}
.step {
  display: flex;
  align-items: center;
  gap: 7px;
  flex: 1;
  min-width: max-content;
  color: var(--dim);
}
.step-dot {
  width: 19px;
  height: 19px;
  border-radius: 50%;
  border: 1px solid var(--line-strong);
  display: grid;
  place-items: center;
  font-size: 8px;
  font-family: var(--mono);
  color: var(--dim);
  flex: none;
}
.step-label {
  font-size: 10.5px;
  white-space: nowrap;
}
.step.done {
  color: var(--muted);
}
.step.done .step-dot {
  border-color: rgba(45, 212, 191, 0.35);
  background: rgba(45, 212, 191, 0.08);
  color: var(--teal);
}
.step.active {
  color: var(--teal);
}
.step.active .step-dot {
  border-color: var(--teal);
  background: var(--teal);
  color: #031412;
  box-shadow: 0 0 0 4px rgba(45, 212, 191, 0.12);
}
.step.branch .step-dot {
  border-color: var(--amber);
  color: var(--amber);
}
.step-arrow {
  color: #32475c;
  flex: none;
}
.branch-banner,
.analyzing-banner {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 10px 13px;
  border-radius: 9px;
  margin-bottom: 12px;
  font-size: 11.5px;
  border: 1px solid var(--line);
}
.branch-amber { color: var(--amber); background: rgba(251, 191, 36, 0.055); border-color: rgba(251, 191, 36, 0.2); }
.branch-rose { color: #fda4af; background: rgba(253, 164, 175, 0.055); border-color: rgba(253, 164, 175, 0.2); }
.branch-red { color: var(--red); background: rgba(251, 113, 133, 0.055); border-color: rgba(251, 113, 133, 0.2); }
.analyzing-banner {
  color: var(--cyan);
  background: rgba(56, 189, 248, 0.05);
  border-color: rgba(56, 189, 248, 0.2);
}
.analyzing-banner strong {
  display: block;
  font-size: 11.5px;
}
.analyzing-banner .btn {
  margin-left: auto;
}
.detail-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 332px;
  gap: 16px;
  align-items: start;
}
.detail-main {
  min-width: 0;
}
.tabs {
  padding: 0 12px;
  margin-bottom: 12px;
  overflow-x: auto;
}
.tab-count {
  font-family: var(--mono);
  font-size: 9px;
  color: var(--dim);
  padding: 0 4px;
  border-radius: 4px;
  background: rgba(148, 163, 184, 0.08);
}
.tab-alert {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--violet);
  box-shadow: 0 0 7px var(--violet);
  display: inline-block;
  vertical-align: middle;
}
.tab-panel {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.finding-card .card-body {
  padding-top: 17px;
}
.finding-hero {
  display: flex;
  justify-content: space-between;
  gap: 18px;
  align-items: flex-start;
}
.finding-hero h2 {
  font-size: 20px;
  letter-spacing: -0.02em;
}
.finding-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 10px;
}
.finding-rule-list {
  display: flex;
  flex-direction: column;
  gap: 5px;
  align-items: flex-end;
  flex: none;
}
.rule-pill {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 10px;
  border: 1px solid var(--line);
  border-radius: 5px;
  padding: 3px 7px;
  color: var(--muted);
  background: rgba(5, 13, 24, 0.45);
}
.rule-pill:hover {
  color: var(--teal);
  border-color: rgba(45, 212, 191, 0.3);
}
.narrative-block {
  margin-top: 16px;
  padding: 12px 14px;
  border: 1px solid rgba(167, 139, 250, 0.2);
  background: rgba(167, 139, 250, 0.04);
  border-radius: 8px;
}
.narrative-head {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 10px;
  color: var(--violet);
  font-weight: 550;
}
.narrative-head .badge {
  margin-left: auto;
}
.narrative-block p {
  margin-top: 7px;
  color: var(--text-soft);
  font-size: 11.5px;
  line-height: 1.7;
}
.narrative-basis {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 5px;
  margin-top: 8px;
}
.narrative-basis .caption {
  margin-right: 3px;
}
.narrative-basis .mono {
  font-size: 8px;
  color: var(--muted);
  border: 1px solid var(--line);
  border-radius: 4px;
  padding: 2px 5px;
  background: rgba(5, 13, 24, 0.4);
}
.check-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
  margin-top: 18px;
  padding-top: 15px;
  border-top: 1px solid var(--line);
}
.check-item {
  display: flex;
  gap: 8px;
  padding: 8px 9px;
  border: 1px solid var(--line);
  border-radius: 7px;
  background: rgba(5, 13, 24, 0.35);
}
.check-icon {
  width: 19px;
  height: 19px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  flex: none;
  margin-top: 1px;
}
.check-name {
  font-size: 10.5px;
  font-weight: 550;
  color: var(--text-soft);
}
.check-source {
  font-size: 8.5px;
  color: var(--dim);
  margin-top: 1px;
}
.check-note {
  font-size: 9px;
  color: var(--dim);
  line-height: 1.45;
  margin-top: 3px;
}
.uncertainties {
  margin-top: 15px;
  padding: 11px 13px;
  border-left: 2px solid var(--amber);
  background: rgba(251, 191, 36, 0.04);
  border-radius: 0 6px 6px 0;
}
.uncertainties ul,
.assumption-list,
.req-list {
  margin: 0;
  padding-left: 16px;
  color: var(--muted);
  font-size: 10.5px;
  line-height: 1.7;
}
.controls-card .control-list {
  display: flex;
  flex-direction: column;
  gap: 11px;
}
.control-item {
  padding: 13px 14px;
  border: 1px solid var(--line);
  border-radius: 9px;
  background: rgba(5, 13, 24, 0.35);
}
.control-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 9.5px;
  color: var(--teal);
}
.control-item p {
  margin-top: 8px;
  color: var(--text-soft);
  font-size: 12px;
  line-height: 1.7;
}
.control-meta {
  display: flex;
  gap: 15px;
  margin-top: 8px;
  font-size: 10px;
  color: var(--dim);
}
.control-meta span {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.req-list {
  margin-top: 7px;
}
.overview-bottom {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}
.assumption-list {
  margin-top: 12px;
}
.evidence-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}
.evidence-card {
  border: 1px solid var(--line);
  border-radius: 9px;
  overflow: hidden;
  background: rgba(5, 13, 24, 0.35);
}
.evidence-img-wrap {
  position: relative;
  cursor: pointer;
  overflow: hidden;
}
.evidence-img-wrap img {
  width: 100%;
  height: 150px;
  object-fit: cover;
  display: block;
  opacity: 0.92;
  transition: 180ms ease;
}
.evidence-img-wrap:hover img {
  transform: scale(1.02);
  opacity: 1;
}
.demo-flag {
  margin-top: 3px;
}
.demo-flag .badge {
  font-size: 8px;
}
.evidence-body {
  padding: 11px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.evidence-body strong {
  font-size: 11.5px;
}
.obs-list {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 7px;
}
.obs-list .chip {
  font-size: 8.5px;
  padding: 2px 5px;
}
.evidence-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 9px;
  padding-top: 8px;
  border-top: 1px solid var(--line);
}
.decision-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 9px;
}
.decision {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 4px;
  padding: 12px;
  border-radius: 9px;
  border: 1px solid var(--line);
  background: rgba(5, 13, 24, 0.4);
  color: var(--muted);
  text-align: left;
}
.decision strong {
  font-size: 12px;
  color: var(--text-soft);
}
.decision span {
  font-size: 9.5px;
  color: var(--dim);
}
.decision.active {
  border-color: var(--teal);
  background: rgba(45, 212, 191, 0.07);
  color: var(--teal);
}
.decision.active strong {
  color: var(--teal);
}
.decision.danger.active {
  border-color: var(--red);
  background: rgba(251, 113, 133, 0.07);
  color: var(--red);
}
.decision.danger.active strong {
  color: var(--red);
}
.review-record p {
  color: var(--text-soft);
  font-size: 12px;
  line-height: 1.7;
}
.review-meta {
  display: flex;
  gap: 15px;
  margin-top: 12px;
  font-size: 10px;
  color: var(--dim);
}
.review-meta span {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.implementation-record {
  display: flex;
  gap: 10px;
  align-items: center;
  padding: 10px 12px;
  border-radius: 8px;
  background: rgba(45, 212, 191, 0.05);
  border: 1px solid rgba(45, 212, 191, 0.16);
}
.record-icon {
  width: 30px;
  height: 30px;
  border-radius: 8px;
  display: grid;
  place-items: center;
  background: rgba(45, 212, 191, 0.1);
  color: var(--teal);
}
.verify-evidence-list {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 7px;
  max-height: 230px;
  overflow-y: auto;
}
.verify-evidence {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px;
  border: 1px solid var(--line);
  border-radius: 7px;
  background: rgba(5, 13, 24, 0.4);
  color: var(--text-soft);
  text-align: left;
}
.verify-evidence img {
  width: 54px;
  height: 40px;
  object-fit: cover;
  border-radius: 4px;
  opacity: 0.85;
}
.verify-evidence.selected {
  border-color: var(--teal);
  box-shadow: 0 0 0 1px rgba(45, 212, 191, 0.25);
}
.verify-evidence:disabled {
  opacity: 0.35;
  cursor: not-allowed;
}
.verify-evidence .check {
  margin-left: auto;
  color: var(--teal);
}
.confirm-line {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin-top: 14px;
  font-size: 10.5px;
  color: var(--muted);
}
.confirm-line input {
  accent-color: var(--teal);
  margin-top: 2px;
}
.verify-head {
  display: flex;
  align-items: center;
  gap: 14px;
}
.verify-big {
  width: 52px;
  height: 52px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  flex: none;
}
.verify-big.ok {
  color: var(--green);
  background: rgba(52, 211, 153, 0.1);
  border: 1px solid rgba(52, 211, 153, 0.28);
}
.verify-big.fail {
  color: var(--red);
  background: rgba(251, 113, 133, 0.1);
  border: 1px solid rgba(251, 113, 133, 0.28);
}
.verify-head h2 {
  font-size: 17px;
}
.verify-head p {
  margin-top: 4px;
}
.verify-checks {
  margin-top: 16px;
  border-top: 1px solid var(--line);
}
.verify-check {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 8px 0;
  border-bottom: 1px solid rgba(124, 160, 196, 0.08);
  font-size: 10.5px;
}
.verify-check .dim {
  margin-left: auto;
  font-size: 9px;
}
.reopen-box {
  margin-top: 20px;
  padding-top: 16px;
  border-top: 1px solid var(--line);
}
.timeline {
  position: relative;
  padding-left: 6px;
}
.timeline-item {
  display: flex;
  gap: 12px;
  position: relative;
  padding-bottom: 18px;
}
.timeline-item::before {
  content: "";
  position: absolute;
  left: 4px;
  top: 12px;
  bottom: 0;
  width: 1px;
  background: var(--line);
}
.timeline-item:last-child::before {
  display: none;
}
.timeline-dot {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  flex: none;
  margin-top: 5px;
  background: currentColor;
  box-shadow: 0 0 8px currentColor;
  z-index: 1;
}
.timeline-body {
  flex: 1;
  min-width: 0;
}
.timeline-top {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.timeline-top strong {
  font-size: 11.5px;
  font-weight: 600;
}
.event-detail {
  margin-top: 6px;
}
.event-detail summary {
  font-size: 9.5px;
  color: var(--dim);
  cursor: pointer;
}
.event-detail pre {
  margin: 6px 0 0;
  padding: 9px;
  border: 1px solid var(--line);
  border-radius: 6px;
  background: rgba(5, 13, 24, 0.6);
  font-size: 9px;
  color: var(--muted);
  overflow: auto;
  max-height: 180px;
}
.detail-rail {
  display: flex;
  flex-direction: column;
  gap: 12px;
  position: sticky;
  top: 78px;
}
.run-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding-bottom: 9px;
  border-bottom: 1px solid var(--line);
}
.trace-mini {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 10px;
}
.trace-mini-item {
  display: flex;
  gap: 8px;
  align-items: flex-start;
}
.trace-seq {
  font-size: 8px;
  color: var(--dim);
  border: 1px solid var(--line);
  border-radius: 4px;
  width: 20px;
  height: 18px;
  display: grid;
  place-items: center;
  flex: none;
}
.trace-node {
  font-size: 10px;
  color: var(--text-soft);
  line-height: 1.35;
}
.rail-list {
  margin: 0;
  padding-left: 15px;
  color: var(--muted);
  font-size: 10.5px;
  line-height: 1.75;
}
.add-evidence-list {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 7px;
  max-height: 260px;
  overflow-y: auto;
  margin-top: 8px;
}
.add-evidence {
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 5px;
  border: 1px solid var(--line);
  border-radius: 7px;
  background: rgba(5, 13, 24, 0.4);
  color: var(--text-soft);
  text-align: left;
}
.add-evidence img {
  width: 52px;
  height: 42px;
  object-fit: cover;
  border-radius: 4px;
  opacity: 0.85;
}
.add-evidence.selected {
  border-color: var(--teal);
}
.add-evidence .check {
  margin-left: auto;
  color: var(--teal);
}
.upload-box {
  margin-top: 8px;
  padding: 12px;
  border: 1px dashed var(--line-strong);
  border-radius: 8px;
  background: rgba(5, 13, 24, 0.3);
  display: flex;
  flex-direction: column;
  gap: 7px;
}
.upload-box input {
  font-size: 10.5px;
  color: var(--muted);
}
@media (max-width: 1350px) {
  .detail-grid {
    grid-template-columns: 1fr;
  }
  .detail-rail {
    position: static;
    display: grid;
    grid-template-columns: 1fr 1fr;
  }
}
@media (max-width: 900px) {
  .detail-head {
    flex-direction: column;
    align-items: flex-start;
  }
  .check-grid,
  .overview-bottom,
  .evidence-grid,
  .decision-grid,
  .detail-rail,
  .add-evidence-list {
    grid-template-columns: 1fr;
  }
  .finding-hero {
    flex-direction: column;
  }
  .finding-rule-list {
    align-items: flex-start;
  }
}
</style>
