import { reactive } from 'vue'
import { api } from './api'
import type { Health, Summary } from './types'

export interface Toast {
  id: number
  message: string
  kind: 'success' | 'error' | 'info' | 'warning'
}

let toastSeed = 0

export const store = reactive({
  health: null as Health | null,
  summary: null as Summary | null,
  booting: true,
  bootError: '',
  toasts: [] as Toast[],
  sidebarCollapsed: false,
})

export async function bootstrap() {
  store.booting = true
  store.bootError = ''
  try {
    const [health, summary] = await Promise.all([
      api.get<Health>('/health'),
      api.get<Summary>('/summary'),
    ])
    store.health = health
    store.summary = summary
  } catch (error: any) {
    store.bootError = error?.message || '无法连接后端服务'
  } finally {
    store.booting = false
  }
}

export async function refreshSummary() {
  try {
    store.summary = await api.get<Summary>('/summary')
  } catch {
    /* keep last known summary */
  }
}

export function toast(message: string, kind: Toast['kind'] = 'info', duration = 4200) {
  const id = ++toastSeed
  store.toasts.push({ id, message, kind })
  window.setTimeout(() => dismissToast(id), duration)
}

export function dismissToast(id: number) {
  const index = store.toasts.findIndex((item) => item.id === id)
  if (index >= 0) store.toasts.splice(index, 1)
}

export function errorMessage(error: any): string {
  if (!error) return '未知错误'
  if (error.code && error.message) return `[${error.code}] ${error.message}`
  return error.message || String(error)
}
