from __future__ import annotations

import json
import re
from typing import Any

import httpx
from pydantic import BaseModel, Field, ValidationError

from .config import MODEL_API_KEY, MODEL_BASE_URL, MODEL_NAME, MODEL_TIMEOUT_SECONDS


class LiveModelError(RuntimeError):
    pass


class ReasoningBasis(BaseModel):
    type: str = Field(pattern="^(evidence|rule|finding|guid)$")
    id: str


class LiveNarrative(BaseModel):
    summary: str = Field(min_length=1, max_length=600)
    reasoning_basis: list[ReasoningBasis] = Field(default_factory=list, max_length=20)
    uncertainties: list[str] = Field(default_factory=list, max_length=20)


def _allowed_ids(context: dict[str, Any]) -> set[str]:
    allowed: set[str] = set()
    allowed.update(context.get("allowed_guids", []))
    allowed.update(context.get("allowed_rule_ids", []))
    allowed.update(context.get("allowed_evidence_ids", []))
    finding_id = context.get("finding_id")
    if finding_id:
        allowed.add(finding_id)
    return {str(item) for item in allowed if item}


def _extract_json(text: str) -> str:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start >= 0 and end > start:
        return cleaned[start : end + 1]
    return cleaned


def live_narrative(context: dict[str, Any]) -> dict[str, Any]:
    """Call an OpenAI-compatible chat endpoint and validate the result.

    Only facts already present in ``context`` are allowed. The caller supplies the
    whitelist; unknown GUID / rule / evidence IDs cause a hard failure (not a
    silent fallback to demo templates).
    """
    if not (MODEL_BASE_URL and MODEL_API_KEY and MODEL_NAME):
        raise LiveModelError("MODEL_BASE_URL / MODEL_API_KEY / MODEL_NAME 配置不完整")
    allowed = _allowed_ids(context)
    system = (
        "你是施工安全协同 Agent 的语言归纳层。"
        "只能使用用户消息中给出的证据、规则、检查项和工具结果，不得编造 GUID、条款、证据或数值。"
        "不得批准、不得宣布现场合规、不得把未知写成 false。"
        "只输出一个 JSON 对象，字段为 summary（不超过300字）、reasoning_basis（数组，元素含 type 和 id）、"
        "uncertainties（字符串数组）。不要输出 Markdown。"
    )
    payload = {
        "model": MODEL_NAME,
        "temperature": 0.1,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": json.dumps(context, ensure_ascii=False)},
        ],
    }
    url = MODEL_BASE_URL.rstrip("/") + "/chat/completions"
    try:
        with httpx.Client(timeout=MODEL_TIMEOUT_SECONDS) as client:
            response = client.post(
                url,
                headers={
                    "Authorization": f"Bearer {MODEL_API_KEY}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
        response.raise_for_status()
        body = response.json()
        content = body["choices"][0]["message"]["content"]
    except Exception as exc:  # noqa: BLE001 - converted to an explicit run failure
        raise LiveModelError(f"真实模型调用失败：{type(exc).__name__}: {str(exc)[:300]}") from exc

    try:
        narrative = LiveNarrative.model_validate_json(_extract_json(content))
    except ValidationError as exc:
        raise LiveModelError(f"真实模型输出未通过 Pydantic 校验：{exc}") from exc
    except Exception as exc:  # noqa: BLE001
        raise LiveModelError(f"真实模型输出不是合法 JSON：{exc}") from exc

    unknown = [item.id for item in narrative.reasoning_basis if item.id not in allowed]
    if unknown:
        raise LiveModelError(f"真实模型输出包含白名单之外的引用：{unknown}")

    # Free-text summaries must not smuggle in unknown GUIDs / IDs.
    for token in re.findall(r"[A-Za-z0-9_$]{18,}", narrative.summary):
        if token not in allowed and re.fullmatch(r"[0-9A-Za-z_$]{18,}", token):
            raise LiveModelError(f"summary 包含白名单之外的标识符：{token}")

    return {
        "summary": narrative.summary,
        "reasoning_basis": [item.model_dump() for item in narrative.reasoning_basis],
        "uncertainties": narrative.uncertainties,
        "label": "真实模型输出（已校验）",
        "provider": MODEL_BASE_URL,
        "model": MODEL_NAME,
    }
