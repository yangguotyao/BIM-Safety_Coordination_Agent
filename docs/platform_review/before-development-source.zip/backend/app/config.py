from __future__ import annotations

import os
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1]          # .../02_网站源码/backend
SOURCE_DIR = APP_DIR.parent                            # .../02_网站源码
PACKAGE_ROOT = SOURCE_DIR.parent                       # 交付包根目录
DATA_ROOT = Path(os.getenv("DATA_ROOT", PACKAGE_ROOT / "01_资料与依据")).resolve()
RUNTIME_DIR = Path(os.getenv("RUNTIME_DIR", APP_DIR / "runtime")).resolve()
FRONTEND_DIST = Path(os.getenv("FRONTEND_DIST", SOURCE_DIR / "frontend" / "dist")).resolve()
DB_PATH = Path(os.getenv("DB_PATH", RUNTIME_DIR / "app.db")).resolve()
UPLOAD_DIR = RUNTIME_DIR / "uploads"
EXPORT_DIR = RUNTIME_DIR / "exports"
MESH_CACHE_DIR = RUNTIME_DIR / "mesh_cache"

DEMO_MODE = os.getenv("DEMO_MODE", "true").strip().lower() not in {"0", "false", "no", "off"}
MODEL_BASE_URL = os.getenv("MODEL_BASE_URL", "").strip()
MODEL_API_KEY = os.getenv("MODEL_API_KEY", "").strip()
MODEL_NAME = os.getenv("MODEL_NAME", "").strip()
MODEL_TIMEOUT_SECONDS = int(os.getenv("MODEL_TIMEOUT_SECONDS", "45"))

HOST = os.getenv("HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", "8000"))
DEMO_CLOCK = os.getenv("DEMO_CLOCK", "2026-10-16T09:00:00+08:00")

MODEL_ID = "S1-bSDD-example"
MODEL_VERSION = "4075c44a6e47"
PROJECT_ID = "S1-DEMO"
ZONE_ID = "ZONE-S1-L05-EDGE"
TASK_ID = "TASK-S1-001"
STOREY_GUID = "1Vhy2b2Mj9FRewx9CZZoux"
TARGET_GUID = "0FOHK4aT910wgskSbVHn0U"

MAX_UPLOAD_BYTES = 20 * 1024 * 1024
ALLOWED_UPLOAD_EXT = {".png", ".jpg", ".jpeg", ".pdf"}
ALLOWED_UPLOAD_MIME = {
    "image/png",
    "image/jpeg",
    "application/pdf",
    "application/octet-stream",
}


def ensure_dirs() -> None:
    for path in (RUNTIME_DIR, UPLOAD_DIR, EXPORT_DIR, MESH_CACHE_DIR):
        path.mkdir(parents=True, exist_ok=True)


def live_model_configured() -> bool:
    return bool(MODEL_BASE_URL and MODEL_API_KEY and MODEL_NAME)


def runtime_mode() -> str:
    if DEMO_MODE:
        return "demo"
    return "live" if live_model_configured() else "live_incomplete"
