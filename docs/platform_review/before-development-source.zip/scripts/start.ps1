$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceDir = Split-Path -Parent $ScriptDir
$PackageRoot = Split-Path -Parent $SourceDir
$BackendDir = Join-Path $SourceDir "backend"
$FrontendDir = Join-Path $SourceDir "frontend"
$DataRoot = if ($env:DATA_ROOT) { $env:DATA_ROOT } else { Join-Path $PackageRoot "01_资料与依据" }
$RuntimeDir = if ($env:RUNTIME_DIR) { $env:RUNTIME_DIR } else { Join-Path $BackendDir "runtime" }
$Port = if ($env:PORT) { $env:PORT } else { "8000" }
$HostName = if ($env:HOST) { $env:HOST } else { "127.0.0.1" }

$env:DATA_ROOT = $DataRoot
$env:RUNTIME_DIR = $RuntimeDir
$env:PORT = $Port
$env:HOST = $HostName

New-Item -ItemType Directory -Force -Path $RuntimeDir | Out-Null
if (-not (Test-Path $DataRoot)) {
  Write-Host "资料目录不存在：$DataRoot" -ForegroundColor Red
  exit 1
}

$listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($listener) {
  Write-Host "端口 $Port 已被占用；可设置 `$env:PORT=8001 后重试。" -ForegroundColor Red
  exit 1
}

Set-Location $BackendDir
if (-not (Test-Path ".venv\Scripts\python.exe")) {
  python -m venv --system-site-packages .venv
}
& ".venv\Scripts\python.exe" -c "import fastapi, pydantic, uvicorn, langgraph, ifcopenshell" 2>$null
if ($LASTEXITCODE -ne 0) {
  & ".venv\Scripts\python.exe" -m pip install --no-cache-dir -r requirements.txt
}

if (-not (Test-Path (Join-Path $FrontendDir "dist\index.html"))) {
  Set-Location $FrontendDir
  npm install --no-audit --no-fund
  npm run build
  Set-Location $BackendDir
}

Write-Host ""
Write-Host "BIM 施工安全协同平台"
Write-Host "地址      http://${HostName}:${Port}"
Write-Host "API 文档  http://${HostName}:${Port}/api/docs"
Write-Host "资料根目录 $DataRoot"
Write-Host "运行目录   $RuntimeDir"
Write-Host ""

& ".venv\Scripts\python.exe" -m uvicorn app.main:app --host $HostName --port $Port
