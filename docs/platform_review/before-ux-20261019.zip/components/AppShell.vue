<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import {
  Activity,
  BookOpen,
  Box,
  ChevronLeft,
  ChevronRight,
  CircleDot,
  FileText,
  FlaskConical,
  GitBranch,
  Images,
  LayoutDashboard,
  ShieldCheck,
  Wifi,
  WifiOff,
} from 'lucide-vue-next'
import { bootstrap, store } from '../store'
import { formatDateTime } from '../utils'
import ToastHost from './ToastHost.vue'

const route = useRoute()
const collapsed = ref(false)

const nav = [
  {
    label: '工作台',
    items: [
      { to: '/', label: '总览', icon: LayoutDashboard, exact: true },
      { to: '/bim', label: 'BIM 模型', icon: Box },
      { to: '/cases', label: '安全案例', icon: ShieldCheck },
      { to: '/agent', label: 'Agent 工作流', icon: GitBranch },
    ],
  },
  {
    label: '知识与证据',
    items: [
      { to: '/knowledge', label: '规范知识库', icon: BookOpen },
      { to: '/evidence', label: '证据库', icon: Images },
    ],
  },
  {
    label: '验证与交付',
    items: [
      { to: '/acceptance', label: '验收实验室', icon: FlaskConical },
      { to: '/about', label: '方案与边界', icon: FileText },
    ],
  },
]

const currentTitle = computed(() => (route.meta.title as string) || '总览')
const currentEyebrow = computed(() => (route.meta.eyebrow as string) || 'BIM SAFETY')
const isActive = (item: { to: string; exact?: boolean }) => {
  if (item.exact) return route.path === item.to
  return route.path === item.to || route.path.startsWith(`${item.to}/`)
}
const clock = computed(() => {
  const value = store.health?.demo_clock || store.summary?.demo_clock
  return formatDateTime(value)
})
const online = computed(() => Boolean(store.health?.ok))
const modeLabel = computed(() => {
  if (store.health?.mode === 'live') return 'LIVE'
  if (store.health?.mode === 'live_incomplete') return 'LIVE INCOMPLETE'
  return 'DEMO'
})

onMounted(() => {
  bootstrap()
})
</script>

<template>
  <div class="shell" :class="{ collapsed }">
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-mark">
          <svg viewBox="0 0 32 32" aria-hidden="true">
            <path d="M16 3 4 9.5v13L16 29l12-6.5v-13L16 3Z" fill="none" stroke="currentColor" stroke-width="1.4" />
            <path d="M16 3v13m0 0 12-6.5M16 16 4 9.5M16 16v13" fill="none" stroke="currentColor" stroke-width="1.1" opacity=".55" />
            <circle cx="16" cy="16" r="2.6" fill="currentColor" />
          </svg>
        </div>
        <div class="brand-text" v-show="!collapsed">
          <div class="brand-name">BIM·SAFETY</div>
          <div class="brand-sub">施工安全协同平台</div>
        </div>
        <button class="collapse-btn" type="button" :title="collapsed ? '展开侧栏' : '收起侧栏'" @click="collapsed = !collapsed">
          <ChevronRight v-if="collapsed" :size="15" />
          <ChevronLeft v-else :size="15" />
        </button>
      </div>

      <div class="project-card" v-show="!collapsed">
        <div class="row" style="justify-content: space-between">
          <span class="caption">ACTIVE PROJECT</span>
          <span class="badge tone-teal badge-dot">S1</span>
        </div>
        <div class="project-name">S1 · 05 层板边检查</div>
        <div class="project-meta mono">bSDD / IFC2X3 / 4075c44a6e47</div>
      </div>

      <nav class="nav">
        <div v-for="group in nav" :key="group.label" class="nav-group">
          <div class="nav-label" v-show="!collapsed">{{ group.label }}</div>
          <router-link
            v-for="item in group.items"
            :key="item.to"
            :to="item.to"
            class="nav-item"
            :class="{ active: isActive(item) }"
            :title="collapsed ? item.label : undefined"
          >
            <component :is="item.icon" :size="17" :stroke-width="1.8" />
            <span v-show="!collapsed">{{ item.label }}</span>
            <i class="nav-glow" />
          </router-link>
        </div>
      </nav>

      <div class="sidebar-foot">
        <div class="status-line" :title="online ? '后端已连接' : '后端未连接'">
          <component :is="online ? Wifi : WifiOff" :size="14" />
          <span v-show="!collapsed">{{ online ? '后端在线' : '后端离线' }}</span>
          <span class="status-dot" :class="{ off: !online }" />
        </div>
        <div class="status-line dim" v-show="!collapsed">
          <Activity :size="13" />
          <span>SQLite · FTS5 · {{ store.health?.ifcopenshell?.available ? 'IfcOpenShell' : 'IFC 离线' }}</span>
        </div>
        <div class="version" v-show="!collapsed">v1.0 · CASE STUDY</div>
      </div>
    </aside>

    <div class="main">
      <header class="topbar">
        <div class="crumbs">
          <span class="caption">{{ currentEyebrow }}</span>
          <ChevronRight :size="12" class="dim" />
          <span>{{ currentTitle }}</span>
        </div>
        <div class="top-right">
          <div class="clock">
            <CircleDot :size="13" class="clock-dot" />
            <span class="mono">{{ clock }}</span>
            <span class="clock-label">演示时钟</span>
          </div>
          <span class="badge" :class="store.health?.mode === 'live' ? 'tone-green' : 'tone-cyan'">
            <span class="mode-dot" />
            {{ modeLabel }}
          </span>
          <span class="badge tone-slate mono">S1 / 05F</span>
        </div>
      </header>

      <main class="content">
        <div v-if="store.bootError" class="boot-error card">
          <WifiOff :size="18" />
          <div>
            <strong>无法连接后端服务</strong>
            <div class="small muted">{{ store.bootError }} · 请确认 uvicorn 运行在 127.0.0.1:8000</div>
          </div>
          <button class="btn btn-sm" @click="bootstrap">重试</button>
        </div>
        <slot />
      </main>
    </div>
    <ToastHost />
  </div>
</template>

<style scoped>
.shell {
  min-height: 100vh;
  display: flex;
}
.sidebar {
  position: fixed;
  inset: 0 auto 0 0;
  width: 236px;
  display: flex;
  flex-direction: column;
  padding: 18px 14px 14px;
  background: linear-gradient(180deg, rgba(8, 18, 31, 0.98), rgba(6, 13, 23, 0.98));
  border-right: 1px solid var(--line);
  z-index: 30;
  transition: width 180ms ease;
}
.collapsed .sidebar {
  width: 72px;
  padding-left: 10px;
  padding-right: 10px;
}
.main {
  flex: 1;
  min-width: 0;
  margin-left: 236px;
  transition: margin-left 180ms ease;
  display: flex;
  flex-direction: column;
}
.collapsed .main {
  margin-left: 72px;
}
.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 2px 4px 16px;
  border-bottom: 1px solid var(--line);
  position: relative;
}
.brand-mark {
  width: 34px;
  height: 34px;
  flex: none;
  border-radius: 9px;
  display: grid;
  place-items: center;
  color: #06201d;
  background: linear-gradient(135deg, #5eead4, #2dd4bf 58%, #38bdf8);
  box-shadow: 0 0 24px rgba(45, 212, 191, 0.26);
}
.brand-mark svg {
  width: 23px;
  height: 23px;
}
.brand-name {
  font-size: 13px;
  font-weight: 750;
  letter-spacing: 0.12em;
  color: var(--text);
}
.brand-sub {
  font-size: 10px;
  color: var(--dim);
  margin-top: 1px;
}
.collapse-btn {
  position: absolute;
  right: -4px;
  top: 4px;
  width: 22px;
  height: 22px;
  border-radius: 6px;
  border: 1px solid var(--line);
  background: var(--panel-solid);
  color: var(--dim);
  display: grid;
  place-items: center;
}
.collapse-btn:hover {
  color: var(--teal);
  border-color: rgba(45, 212, 191, 0.35);
}
.project-card {
  margin: 14px 2px 10px;
  padding: 11px 12px;
  border: 1px solid var(--line);
  border-radius: 10px;
  background: linear-gradient(140deg, rgba(45, 212, 191, 0.07), rgba(56, 189, 248, 0.03));
}
.project-name {
  margin-top: 7px;
  font-size: 12.5px;
  font-weight: 600;
}
.project-meta {
  margin-top: 4px;
  font-size: 9.5px;
  color: var(--dim);
}
.nav {
  flex: 1;
  overflow-y: auto;
  padding-top: 8px;
}
.nav-group {
  margin-bottom: 14px;
}
.nav-label {
  padding: 4px 10px 6px;
  font-size: 9px;
  letter-spacing: 0.18em;
  color: #536a82;
  text-transform: uppercase;
  font-weight: 600;
}
.nav-item {
  position: relative;
  display: flex;
  align-items: center;
  gap: 11px;
  height: 38px;
  padding: 0 11px;
  margin: 2px 0;
  border-radius: 8px;
  color: #91a6bd;
  font-size: 12.5px;
  font-weight: 500;
  transition: 140ms ease;
  overflow: hidden;
}
.nav-item:hover {
  color: var(--text);
  background: rgba(148, 163, 184, 0.06);
}
.nav-item.active {
  color: #c7fff8;
  background: linear-gradient(90deg, rgba(45, 212, 191, 0.14), rgba(45, 212, 191, 0.03));
}
.nav-item.active::before {
  content: "";
  position: absolute;
  left: 0;
  width: 2px;
  height: 18px;
  border-radius: 99px;
  background: var(--teal);
  box-shadow: 0 0 12px rgba(45, 212, 191, 0.8);
}
.nav-item.active svg {
  color: var(--teal);
}
.nav-glow {
  position: absolute;
  right: -12px;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: rgba(45, 212, 191, 0.13);
  filter: blur(12px);
  opacity: 0;
}
.nav-item.active .nav-glow {
  opacity: 1;
}
.sidebar-foot {
  border-top: 1px solid var(--line);
  padding: 12px 7px 2px;
  display: flex;
  flex-direction: column;
  gap: 7px;
}
.status-line {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 10.5px;
  color: var(--muted);
}
.status-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--green);
  box-shadow: 0 0 8px var(--green);
  margin-left: auto;
}
.status-dot.off {
  background: var(--red);
  box-shadow: 0 0 8px var(--red);
}
.version {
  font-family: var(--mono);
  font-size: 8.5px;
  letter-spacing: 0.14em;
  color: #445a72;
  padding-left: 1px;
}
.topbar {
  position: sticky;
  top: 0;
  z-index: 20;
  height: 62px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 30px;
  border-bottom: 1px solid var(--line);
  background: rgba(6, 13, 23, 0.78);
  backdrop-filter: blur(16px);
}
.crumbs {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 11.5px;
  color: var(--text-soft);
}
.crumbs .caption {
  color: var(--teal);
}
.top-right {
  display: flex;
  align-items: center;
  gap: 10px;
}
.clock {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 10.5px;
  color: var(--muted);
  border: 1px solid var(--line);
  border-radius: 7px;
  height: 28px;
  padding: 0 9px;
  background: rgba(148, 163, 184, 0.03);
}
.clock-dot {
  color: var(--teal);
  animation: pulse 2s ease-in-out infinite;
}
.clock-label {
  font-size: 9px;
  color: var(--dim);
  border-left: 1px solid var(--line);
  padding-left: 7px;
}
.mode-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: currentColor;
  box-shadow: 0 0 7px currentColor;
}
.content {
  flex: 1;
  min-width: 0;
}
.boot-error {
  margin: 20px 30px 0;
  padding: 14px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  border-color: rgba(251, 113, 133, 0.3);
  color: var(--red);
}
.boot-error strong {
  display: block;
  color: var(--text);
  font-size: 12px;
}
.boot-error .btn {
  margin-left: auto;
}
@media (max-width: 980px) {
  .sidebar {
    width: 72px;
    padding-left: 10px;
    padding-right: 10px;
  }
  .main {
    margin-left: 72px;
  }
  .brand-text,
  .project-card,
  .nav-label,
  .nav-item span,
  .sidebar-foot .status-line span,
  .version {
    display: none !important;
  }
  .collapse-btn {
    display: none;
  }
  .topbar {
    padding: 0 16px;
  }
  .clock,
  .top-right .badge:last-child {
    display: none;
  }
}
</style>
