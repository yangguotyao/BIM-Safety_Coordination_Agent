<script setup lang="ts">
import { Inbox } from 'lucide-vue-next'
defineProps<{ title?: string; detail?: string }>()
</script>

<template>
  <div class="empty">
    <Inbox :size="26" />
    <strong>{{ title || '暂无数据' }}</strong>
    <span class="small">{{ detail || '完成一次操作后，这里会显示实际记录。' }}</span>
    <slot />
  </div>
</template>
