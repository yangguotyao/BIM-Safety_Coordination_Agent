<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import {
  ArrowRight,
  CalendarClock,
  ChevronRight,
  FilePlus2,
  Filter,
  Loader2,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
} from 'lucide-vue-next'
import EmptyState from '../components/EmptyState.vue'
import Modal from '../components/Modal.vue'
import StatusBadge from '../components/StatusBadge.vue'
import { api } from '../api'
import { actorId, errorMessage, refreshSummary, store, toast } from '../store'
import type { CaseBundle, CaseRecord, Evidence } from '../types'
import { formatDateTime, formatNumber, resultLabel, statusLabel } from '../utils'

const router = useRouter()
const cases = ref<CaseRecord[]>([])
const evidenceList = ref<Evidence[]>([])
const loading = ref(true)
const creating = ref(false)
const modalOpen = ref(false)
const search = ref('')
const statusFilter = ref('')
const hideAcceptance = ref(true)
const form = reactive({
  request: '全面检查L05区域临边防护和人员暴露风险，并提出控制措施。',
  title: 'L05 板边安全检查演示',
  evidenceIds: ['EV-001'] as string[],
  asOf: '2026-10-16T09:00:00+08:00',
})

const statuses = ['', 'draft', 'analyzing', 'needs_evidence', 'pending_review', 'approved', 'rectifying', 'pending_verification', 'closed', 'reopened', 'rejected']

const baseCases = computed(() =>
  hideAcceptance.value ? cases.value.filter((item) => !item.title.startsWith('验收 ')) : cases.value,
)
const acceptanceCaseCount = computed(() => cases.value.filter((item) => item.title.startsWith('验收 ')).length)

const filtered = computed(() => {
  let rows = baseCases.value
  if (statusFilter.value) rows = rows.filter((item) => item.status === statusFilter.value)
  if (search.value.trim()) {
    const keyword = search.value.trim().toLowerCase()
    rows = rows.filter(
      (item) =>
        item.title.toLowerCase().includes(keyword) ||
        item.case_id.toLowerCase().includes(keyword) ||
        item.evidence_ids.join(' ').toLowerCase().includes(keyword),
    )
  }
  return rows
})

const counts = computed(() => {
  const result: Record<string, number> = {}
  for (const item of baseCases.value) result[item.status] = (result[item.status] || 0) + 1
  return result
})

async function load() {
  loading.value = true
  try {
    const [caseRows, evidenceRows] = await Promise.all([
      api.get<{ rows: CaseRecord[] }>('/cases'),
      api.get<{ rows: Evidence[] }>('/evidence'),
    ])
    cases.value = caseRows.rows
    evidenceList.value = evidenceRows.rows
  } catch (error: any) {
    toast(errorMessage(error), 'error')
  } finally {
    loading.value = false
  }
}

function openModal() {
  form.title = 'L05 板边安全检查演示'
  form.evidenceIds = ['EV-001']
  form.asOf = '2026-10-16T09:00:00+08:00'
  modalOpen.value = true
}

function toggleEvidence(id: string) {
  if (form.evidenceIds.includes(id)) {
    if (form.evidenceIds.length === 1) {
      toast('至少保留一条证据', 'warning')
      return
    }
    form.evidenceIds = form.evidenceIds.filter((item) => item !== id)
  } else {
    form.evidenceIds = [...form.evidenceIds, id]
  }
}

async function submit(analyze: boolean) {
  if (creating.value) return
  creating.value = true
  try {
    const bundle = await api.post<CaseBundle>('/cases', {
      request_text: form.request.trim(),
      actor_id: actorId,
      title: form.title.trim() || '未命名安全检查案例',
      model_id: 'S1-bSDD-example',
      task_id: 'TASK-S1-001',
      zone_id: 'ZONE-S1-L05-EDGE',
      as_of: form.asOf,
      evidence_ids: form.evidenceIds,
    })
    if (analyze) {
      await api.post(`/cases/${bundle.case.case_id}/analyze`)
      toast('案例已创建，Agent 分析已启动。', 'success')
    } else {
      toast('案例草稿已创建。', 'success')
    }
    modalOpen.value = false
    await load()
    await refreshSummary()
    router.push(`/cases/${bundle.case.case_id}`)
  } catch (error: any) {
    toast(errorMessage(error), 'error')
  } finally {
    creating.value = false
  }
}

function openCase(item: CaseRecord) {
  router.push(`/cases/${item.case_id}`)
}

onMounted(load)
</script>

<template>
  <div class="page cases-page">
    <div class="page-head">
      <div>
        <div class="eyebrow">SAFETY CASES · PERSISTED IN SQLITE</div>
        <h1>安全案例</h1>
        <p class="sub">
          每个案例固定任务、模型版本、区域和检查时刻；分析、审核、实施、复核都写入数据库，刷新不丢失。
        </p>
      </div>
      <div class="head-actions">
        <button class="btn" @click="load"><Filter :size="14" /> 刷新</button>
        <button class="btn btn-primary" @click="openModal"><Plus :size="15" /> 新建案例</button>
      </div>
    </div>

    <div class="case-summary">
      <div class="summary-item">
        <div class="stat">{{ formatNumber(baseCases.length) }}</div>
        <div class="stat-label">业务案例</div>
      </div>
      <div class="summary-item">
        <div class="stat">{{ counts.pending_review || 0 }}</div>
        <div class="stat-label">待人工审核</div>
      </div>
      <div class="summary-item">
        <div class="stat">{{ counts.closed || 0 }}</div>
        <div class="stat-label">已复核关闭</div>
      </div>
      <div class="summary-item">
        <div class="stat">{{ counts.needs_evidence || 0 }}</div>
        <div class="stat-label">待补充证据</div>
      </div>
      <div class="summary-item">
        <div class="stat">{{ store.summary?.risk_candidates || 0 }}</div>
        <div class="stat-label">风险候选</div>
      </div>
    </div>

    <div class="case-toolbar card">
      <div class="status-tabs">
        <button
          v-for="item in statuses"
          :key="item"
          class="status-tab"
          :class="{ active: statusFilter === item }"
          @click="statusFilter = item"
        >
          {{ item ? statusLabel(item) : '全部' }}
          <span v-if="item && counts[item]">{{ counts[item] }}</span>
        </button>
      </div>
      <div class="toolbar-right">
        <label class="toggle-line">
          <input v-model="hideAcceptance" type="checkbox" />
          <span>隐藏验收案例 ({{ acceptanceCaseCount }})</span>
        </label>
        <div class="search-box">
          <Search :size="14" class="dim" />
          <input v-model="search" class="input" placeholder="搜索标题 / 案例 ID / 证据" />
        </div>
      </div>
    </div>

    <div v-if="loading" class="loading-state card">
      <Loader2 :size="18" class="spin" />
      <span>读取案例数据库…</span>
    </div>

    <div v-else-if="filtered.length" class="case-grid">
      <article v-for="item in filtered" :key="item.case_id" class="case-card card" @click="openCase(item)">
        <div class="case-card-top">
          <div class="case-icon" :class="`tone-${item.status === 'closed' ? 'green' : item.status === 'needs_evidence' ? 'amber' : item.status === 'pending_review' ? 'violet' : 'cyan'}`">
            <ShieldCheck :size="18" />
          </div>
          <StatusBadge :status="item.status" dot />
        </div>
        <h3>{{ item.title }}</h3>
        <div class="mono case-id">{{ item.case_id }}</div>
        <div class="case-meta">
          <span><CalendarClock :size="12" /> {{ formatDateTime(item.as_of) }}</span>
          <span class="mono">{{ item.evidence_ids.join(' · ') || '无证据' }}</span>
        </div>
        <div v-if="item.findings?.length" class="finding-line" :class="`tone-${item.findings[0].result === 'risk_candidate' ? 'red' : item.findings[0].result === 'needs_evidence' ? 'amber' : 'green'}`">
          <span class="result-dot" />
          {{ resultLabel(item.findings[0].result) }}
          <span class="dim" style="margin-left: auto">v{{ item.version }}</span>
        </div>
        <div v-else class="finding-line muted">
          <Sparkles :size="12" /> 尚未分析
          <span class="dim" style="margin-left: auto">v{{ item.version }}</span>
        </div>
        <div class="case-card-foot">
          <span class="small dim">{{ item.model_version }}</span>
          <span class="open-link">打开案例 <ArrowRight :size="13" /></span>
        </div>
      </article>
    </div>

    <div v-else class="card">
      <EmptyState
        title="没有匹配的案例"
        detail="调整筛选条件，或新建一个案例。隐藏验收案例后，只显示业务演示案例。"
      >
        <button class="btn btn-sm btn-primary" style="margin-top: 8px" @click="openModal">新建案例</button>
      </EmptyState>
    </div>

    <Modal :open="modalOpen" title="新建 Safety Case" subtitle="固定案例边界；分析会真实调用 LangGraph 与 SQLite。" width="760px" @close="modalOpen = false">
      <div class="field">
        <label>案例标题</label>
        <input v-model="form.title" class="input" placeholder="例如：L05 板边安全检查演示" />
      </div>
      <div class="field" style="margin-top: 14px">
        <label for="new-task">交给 Agent 的检查任务</label>
        <textarea id="new-task" v-model="form.request" class="textarea" maxlength="1500" placeholder="例如：只检查L05区域栏杆高度是否满足要求" />
        <span class="muted small">可选择综合检查、栏杆高度、防护固定与连续性、人员暴露与距离。</span>
      </div>
      <div class="form-row" style="margin-top: 14px">
        <div class="field">
          <label>项目 / 模型</label>
          <input class="input" value="S1-DEMO · S1-bSDD-example" disabled />
        </div>
        <div class="field">
          <label>检查时刻（ISO8601；演示默认 2026-10-16T09:00）</label>
          <input v-model="form.asOf" class="input mono" />
        </div>
        <div class="field">
          <label>区域</label>
          <input class="input" value="ZONE-S1-L05-EDGE · 05 层板边" disabled />
        </div>
        <div class="field">
          <label>施工任务</label>
          <input class="input" value="TASK-S1-001 · 机电材料转运演示" disabled />
        </div>
      </div>

      <div class="field" style="margin-top: 16px">
        <label>选择检查证据（{{ form.evidenceIds.length }} 条）</label>
        <div class="evidence-picker">
          <button
            v-for="item in evidenceList"
            :key="item.evidence_id"
            type="button"
            class="evidence-option"
            :class="{ selected: form.evidenceIds.includes(item.evidence_id) }"
            @click="toggleEvidence(item.evidence_id)"
          >
            <img :src="item.image_url" :alt="item.label" />
            <div class="evidence-option-body">
              <span class="mono">{{ item.evidence_id }}</span>
              <strong>{{ item.label }}</strong>
              <small>{{ item.stage }} · {{ item.captured_at.slice(11, 16) }}</small>
            </div>
            <span class="select-mark">✓</span>
          </button>
        </div>
      </div>

      <div class="notice warn" style="margin-top: 14px">
        <ShieldCheck :size="13" />
        <span>
          证据图为“真实 IFC 几何派生 + 模拟现场观察”，不是现场照片。分析不会把未知字段当作 false，也不会自动判定现场安全。
        </span>
      </div>

      <template #footer>
        <button class="btn" :disabled="creating" @click="submit(false)">仅创建草稿</button>
        <button class="btn btn-primary" :disabled="creating" @click="submit(true)">
          <Loader2 v-if="creating" :size="14" class="spin" />
          <FilePlus2 v-else :size="14" />
          创建并分析
        </button>
      </template>
    </Modal>
  </div>
</template>

<style scoped>
.case-summary {
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 1px;
  border: 1px solid var(--line);
  border-radius: 12px;
  overflow: hidden;
  background: var(--line);
  margin-bottom: 16px;
}
.summary-item {
  background: rgba(9, 19, 32, 0.82);
  padding: 13px 16px;
}
.summary-item .stat {
  font-size: 21px;
}
.case-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  padding: 10px 14px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}
.status-tabs {
  display: flex;
  gap: 2px;
  overflow-x: auto;
  flex-wrap: wrap;
}
.status-tab {
  border: 1px solid transparent;
  background: transparent;
  color: var(--dim);
  font-size: 11px;
  padding: 6px 9px;
  border-radius: 6px;
  white-space: nowrap;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.status-tab span {
  font-family: var(--mono);
  font-size: 9px;
  color: var(--muted);
  background: rgba(148, 163, 184, 0.09);
  border-radius: 4px;
  padding: 0 4px;
}
.status-tab:hover {
  color: var(--text-soft);
  background: rgba(148, 163, 184, 0.05);
}
.status-tab.active {
  color: var(--teal);
  background: rgba(45, 212, 191, 0.08);
  border-color: rgba(45, 212, 191, 0.22);
}
.toolbar-right {
  display: flex;
  align-items: center;
  gap: 14px;
}
.toggle-line {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 10.5px;
  color: var(--muted);
  white-space: nowrap;
}
.toggle-line input {
  accent-color: var(--teal);
}
.search-box {
  display: flex;
  align-items: center;
  gap: 7px;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 0 9px;
  background: rgba(5, 13, 24, 0.6);
  min-width: 260px;
}
.search-box .input {
  border: none;
  background: transparent;
  height: 32px;
  padding: 0;
  font-size: 11.5px;
}
.search-box .input:focus {
  box-shadow: none;
}
.loading-state {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 9px;
  padding: 50px;
  color: var(--muted);
  font-size: 12px;
}
.case-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 14px;
}
.case-card {
  padding: 16px;
  cursor: pointer;
  transition: 160ms ease;
  position: relative;
  overflow: hidden;
}
.case-card::before {
  content: "";
  position: absolute;
  inset: 0 0 auto 0;
  height: 2px;
  background: linear-gradient(90deg, rgba(45, 212, 191, 0.55), transparent);
  opacity: 0;
  transition: 160ms ease;
}
.case-card:hover {
  transform: translateY(-2px);
  border-color: rgba(45, 212, 191, 0.28);
}
.case-card:hover::before {
  opacity: 1;
}
.case-card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.case-icon {
  width: 34px;
  height: 34px;
  border-radius: 9px;
  display: grid;
  place-items: center;
  border: 1px solid currentColor;
}
.case-card h3 {
  margin-top: 12px;
  font-size: 14px;
  line-height: 1.45;
}
.case-id {
  font-size: 9.5px;
  color: var(--dim);
  margin-top: 4px;
}
.case-meta {
  display: flex;
  flex-direction: column;
  gap: 5px;
  margin-top: 13px;
  font-size: 10px;
  color: var(--muted);
}
.case-meta span {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.finding-line {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 12px;
  padding: 7px 9px;
  border-radius: 6px;
  background: rgba(148, 163, 184, 0.05);
  font-size: 10.5px;
  border: 1px solid var(--line);
}
.result-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
  box-shadow: 0 0 7px currentColor;
}
.case-card-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 14px;
  padding-top: 11px;
  border-top: 1px solid var(--line);
}
.open-link {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 10.5px;
  color: var(--teal);
}
.evidence-picker {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 8px;
  max-height: 300px;
  overflow-y: auto;
  padding-right: 3px;
}
.evidence-option {
  position: relative;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: rgba(5, 13, 24, 0.5);
  padding: 0;
  overflow: hidden;
  text-align: left;
  color: var(--text-soft);
  transition: 140ms ease;
}
.evidence-option:hover {
  border-color: var(--line-strong);
}
.evidence-option.selected {
  border-color: var(--teal);
  box-shadow: 0 0 0 2px rgba(45, 212, 191, 0.15);
}
.evidence-option img {
  width: 100%;
  height: 66px;
  object-fit: cover;
  display: block;
  opacity: 0.82;
}
.evidence-option-body {
  padding: 7px;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.evidence-option-body .mono {
  font-size: 8.5px;
  color: var(--teal);
}
.evidence-option-body strong {
  font-size: 10px;
  font-weight: 600;
}
.evidence-option-body small {
  font-size: 8.5px;
  color: var(--dim);
}
.select-mark {
  position: absolute;
  top: 5px;
  right: 5px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: var(--teal);
  color: #041512;
  font-size: 10px;
  opacity: 0;
}
.evidence-option.selected .select-mark {
  opacity: 1;
}
@media (max-width: 1280px) {
  .case-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 860px) {
  .case-grid {
    grid-template-columns: 1fr;
  }
  .case-summary {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .evidence-picker {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
</style>
