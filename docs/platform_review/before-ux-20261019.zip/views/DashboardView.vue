<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import {
  AlertTriangle,
  ArrowRight,
  ArrowUpRight,
  Box,
  CheckCircle2,
  CircleDot,
  Database,
  FileCheck2,
  GitBranch,
  Layers,
  Loader2,
  Play,
  Plus,
  ShieldCheck,
  Sparkles,
} from 'lucide-vue-next'
import FlowDiagram from '../components/FlowDiagram.vue'
import StatusBadge from '../components/StatusBadge.vue'
import EmptyState from '../components/EmptyState.vue'
import { api } from '../api'
import { errorMessage, refreshSummary, store, toast } from '../store'
import { formatDateTime, formatNumber, resultLabel, shortGuid, statusLabel } from '../utils'
import type { CaseBundle, CaseRecord } from '../types'

const router = useRouter()
const creating = ref(false)

const cases = computed(() => (store.summary?.recent_cases || []).filter((item) => !item.title.startsWith('验收 ')))
const demoCase = computed<CaseRecord | null>(() => cases.value[0] || null)
const metrics = computed(() => [
  { label: '模型构件', value: formatNumber(store.summary?.element_count || 16372), unit: '', tone: 'teal', icon: Box },
  { label: '05 层索引', value: formatNumber(store.summary?.storey_element_count || 1247), unit: '', tone: 'cyan', icon: Layers },
  { label: '首屏真实网格', value: String(store.summary?.preview_mesh_count || 35), unit: '', tone: 'blue', icon: Sparkles },
  { label: '现行规范条款', value: String(store.summary?.active_rules || 7), unit: '', tone: 'violet', icon: FileCheck2 },
  { label: '演示证据', value: String(store.summary?.evidence_count || 12), unit: '', tone: 'amber', icon: Database },
  { label: '验收用例', value: `${store.summary?.acceptance?.passed || 0}/12`, unit: '', tone: 'green', icon: CheckCircle2 },
])

const acceptancePercent = computed(() => {
  const value = store.summary?.acceptance
  if (!value?.total) return 0
  return Math.round((value.passed / 12) * 100)
})

async function openDemoCase() {
  if (demoCase.value) {
    router.push(`/cases/${demoCase.value.case_id}`)
    return
  }
  await createRiskCase()
}

async function createRiskCase() {
  if (creating.value) return
  creating.value = true
  try {
    const bundle = await api.post<CaseBundle>('/cases', {
      title: 'L05 板边风险检查演示',
      model_id: 'S1-bSDD-example',
      task_id: 'TASK-S1-001',
      zone_id: 'ZONE-S1-L05-EDGE',
      as_of: '2026-10-16T09:00:00+08:00',
      evidence_ids: ['EV-001'],
    })
    await api.post(`/cases/${bundle.case.case_id}/analyze`)
    await refreshSummary()
    toast('已创建并启动分析，Agent 正在执行六类职责节点。', 'success')
    router.push(`/cases/${bundle.case.case_id}`)
  } catch (error: any) {
    toast(errorMessage(error), 'error')
  } finally {
    creating.value = false
  }
}

function openCase(item: CaseRecord) {
  router.push(`/cases/${item.case_id}`)
}

onMounted(() => {
  if (!store.summary) refreshSummary()
})
</script>

<template>
  <div class="page dashboard">
    <div class="hero">
      <div class="hero-copy">
        <div class="hero-eyebrow">
          <span class="hero-pill"><CircleDot :size="11" /> CASE STUDY · 2026</span>
          <span class="mono dim">S1 / 05F / IFC2X3</span>
        </div>
        <h1>
          把 BIM 空间、施工活动<br />
          <span class="gradient-text">组织成可复核的 Safety Case</span>
        </h1>
        <p class="hero-sub">
          不是让 LLM 直接操作 BIM，而是让 Agent 把<strong>安全任务、构件与空间、施工进度、现场证据和现行规范</strong>连接起来，
          经过风险判定、人工审核、实施与复核，形成可追溯的闭环。
        </p>
        <div class="hero-actions">
          <button class="btn btn-primary btn-lg" @click="openDemoCase">
            <Play :size="15" /> 打开预置案例
          </button>
          <button class="btn btn-lg" :disabled="creating" @click="createRiskCase">
            <Loader2 v-if="creating" :size="15" class="spin" />
            <Plus v-else :size="15" />
            新建风险案例并分析
          </button>
          <router-link class="btn btn-ghost btn-lg" to="/acceptance">
            运行 12 项验收 <ArrowUpRight :size="14" />
          </router-link>
        </div>
        <div class="hero-note">
          <ShieldCheck :size="13" />
          <span>真实 IFC 几何 + 模拟现场观察；页面持续标注“演示示意图 / 非现场照片”。</span>
        </div>
      </div>

      <div class="hero-side">
        <div class="case-orbit card">
          <div class="orbit-head">
            <div>
              <div class="caption">ACTIVE SAFETY CASE</div>
              <div class="orbit-title">{{ demoCase?.title || 'L05 板边安全检查演示' }}</div>
            </div>
            <StatusBadge v-if="demoCase" :status="demoCase.status" dot />
          </div>
          <div class="orbit-map">
            <svg viewBox="0 0 360 150" class="plan-svg" aria-hidden="true">
              <defs>
                <pattern id="grid" width="18" height="18" patternUnits="userSpaceOnUse">
                  <path d="M18 0H0V18" fill="none" stroke="rgba(124,160,196,.14)" stroke-width=".5" />
                </pattern>
              </defs>
              <rect x="0" y="0" width="360" height="150" fill="url(#grid)" />
              <path
                d="M86 22 L292 22 L292 58 L270 58 L270 76 L320 76 L320 112 L272 112 L272 128 L86 128 L86 96 L118 96 L118 74 L86 74 Z"
                fill="rgba(45,212,191,.08)"
                stroke="#2dd4bf"
                stroke-width="1.4"
              />
              <path d="M86 74 L118 74 L118 96 L86 96" fill="none" stroke="#38bdf8" stroke-width="1" opacity=".6" />
              <path d="M292 58 L270 58 L270 76 L320 76" fill="none" stroke="#38bdf8" stroke-width="1" opacity=".55" />
              <line x1="292" y1="22" x2="292" y2="58" stroke="#fb7185" stroke-width="2.4" />
              <circle cx="292" cy="40" r="6" fill="#fbbf24" />
              <circle cx="292" cy="40" r="12" fill="none" stroke="#fbbf24" stroke-width=".8" opacity=".55" />
              <text x="302" y="34" fill="#fbbf24" font-size="8" font-family="monospace">EV-001</text>
              <text x="96" y="18" fill="#637a93" font-size="7" font-family="monospace">05 vijfde verdieping</text>
              <text x="96" y="142" fill="#637a93" font-size="7" font-family="monospace">0FOHK4aT910wgskSbVHn0U · IfcSlab</text>
            </svg>
            <div class="orbit-legend">
              <span><i class="dot teal" /> 真实板边</span>
              <span><i class="dot rose" /> 标注检查边</span>
              <span><i class="dot amber" /> 模拟人员</span>
            </div>
          </div>
          <div class="orbit-meta">
            <div>
              <span class="caption">TASK</span>
              <div class="small">L05 板边区域机电材料转运演示</div>
            </div>
            <div>
              <span class="caption">AS OF</span>
              <div class="small mono">{{ formatDateTime(demoCase?.as_of) }}</div>
            </div>
            <div>
              <span class="caption">EVIDENCE</span>
              <div class="small mono">{{ demoCase?.evidence_ids?.join(' · ') || 'EV-001' }}</div>
            </div>
          </div>
          <button class="orbit-cta" @click="openDemoCase">
            进入案例工作台 <ArrowRight :size="14" />
          </button>
        </div>
      </div>
    </div>

    <div class="metric-row">
      <div v-for="item in metrics" :key="item.label" class="metric card" :class="`accent-${item.tone}`">
        <div class="metric-icon"><component :is="item.icon" :size="15" /></div>
        <div>
          <div class="stat">{{ item.value }}<span class="stat-unit">{{ item.unit }}</span></div>
          <div class="stat-label">{{ item.label }}</div>
        </div>
      </div>
    </div>

    <div class="dashboard-grid">
      <section class="card flow-card">
        <div class="card-head">
          <div>
            <div class="card-title"><GitBranch :size="15" /> 六类职责 Agent 工作流</div>
            <div class="small dim" style="margin-top: 3px">
              LLM 理解与编排，专业工具感知与计算；每个节点写入真实 trace。
            </div>
          </div>
          <router-link class="btn btn-sm" to="/agent">查看实际调用 <ArrowRight :size="13" /></router-link>
        </div>
        <div class="card-body">
          <FlowDiagram compact />
          <div class="flow-foot">
            <div class="flow-step"><span class="mono">01</span> 固定任务 / 区域 / 时刻</div>
            <div class="flow-step"><span class="mono">02</span> 查询真实构件与几何</div>
            <div class="flow-step"><span class="mono">03</span> 匹配证据与 active 条款</div>
            <div class="flow-step"><span class="mono">04</span> 风险判定 → 人工审核 → 复核</div>
          </div>
        </div>
      </section>

      <section class="card status-card">
        <div class="card-head">
          <div class="card-title"><ShieldCheck :size="15" /> 当前闭环状态</div>
          <span class="badge tone-slate">LIVE DB</span>
        </div>
        <div class="card-body">
          <div class="status-big">
            <div class="status-ring" :style="{ '--pct': `${acceptancePercent}%` }">
              <div class="status-ring-inner">
                <strong>{{ store.summary?.acceptance?.passed || 0 }}</strong>
                <span>/ 12</span>
              </div>
            </div>
            <div>
              <div class="strong">验收通过</div>
              <div class="small muted" style="margin-top: 4px">
                {{ store.summary?.acceptance?.total ? '最近一次结果' : '尚未执行 12 项验收' }} · 真实 API 写入
              </div>
              <router-link to="/acceptance" class="small" style="display: inline-flex; align-items: center; gap: 4px; margin-top: 8px">
                打开验收实验室 <ArrowUpRight :size="12" />
              </router-link>
            </div>
          </div>
          <div class="status-bars">
            <div v-for="item in ['closed', 'pending_review', 'needs_evidence', 'reopened']" :key="item" class="status-bar-row">
              <span class="small muted">{{ statusLabel(item) }}</span>
              <div class="bar"><span :style="{ width: `${Math.min(100, (store.summary?.status_counts?.[item] || 0) * 18)}%` }" /></div>
              <span class="mono small">{{ store.summary?.status_counts?.[item] || 0 }}</span>
            </div>
          </div>
          <div class="notice warn" style="margin-top: 14px">
            <AlertTriangle :size="13" />
            <span>风险等级是演示管理策略，不是校准的事故概率；未检查项不代表安全。</span>
          </div>
        </div>
      </section>
    </div>

    <div class="dashboard-lower">
      <section class="card">
        <div class="card-head">
          <div class="card-title"><Layers :size="15" /> 最近案例</div>
          <router-link class="btn btn-sm" to="/cases">全部案例 <ArrowRight :size="13" /></router-link>
        </div>
        <div v-if="cases.length" class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>案例</th>
                <th>状态</th>
                <th>证据</th>
                <th>版本</th>
                <th>更新时间</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in cases.slice(0, 5)" :key="item.case_id" @click="openCase(item)">
                <td>
                  <div class="strong">{{ item.title }}</div>
                  <div class="mono tiny dim">{{ item.case_id }}</div>
                </td>
                <td><StatusBadge :status="item.status" /></td>
                <td class="mono small">{{ item.evidence_ids.join(', ') }}</td>
                <td class="mono small">v{{ item.version }}</td>
                <td class="small dim">{{ formatDateTime(item.updated_at) }}</td>
                <td><ArrowRight :size="14" class="dim" /></td>
              </tr>
            </tbody>
          </table>
        </div>
        <EmptyState v-else title="还没有案例" detail="点击上方“新建风险案例并分析”，创建一个真实写入数据库的 Safety Case。" />
      </section>

      <section class="card evidence-chain">
        <div class="card-head">
          <div class="card-title"><Database :size="15" /> 证据链</div>
          <span class="badge tone-amber">MIXED</span>
        </div>
        <div class="card-body">
          <div class="chain">
            <div class="chain-item">
              <span class="mono">BIM</span>
              <strong>真实构件</strong>
              <small>IFC GUID / 几何 / 楼层</small>
            </div>
            <ArrowRight :size="13" class="dim" />
            <div class="chain-item">
              <span class="mono">EVIDENCE</span>
              <strong>模拟观察</strong>
              <small>防护 / 人员 / 时间</small>
            </div>
            <ArrowRight :size="13" class="dim" />
            <div class="chain-item">
              <span class="mono">RULE</span>
              <strong>现行释义</strong>
              <small>GB 55034 / JGJ 80</small>
            </div>
            <ArrowRight :size="13" class="dim" />
            <div class="chain-item">
              <span class="mono">CASE</span>
              <strong>可复核结论</strong>
              <small>人工批准 / 证据复核</small>
            </div>
          </div>
          <div class="chain-note">
            每个 Finding 保留 <span class="mono">bim_guids / evidence_ids / rule_ids / checks / uncertainties</span>；
            关闭后条件变化可重新打开，历史事件不覆盖。
          </div>
          <router-link class="btn btn-sm" to="/knowledge" style="margin-top: 12px">
            查看 7 条 active 条款 <ArrowRight :size="13" />
          </router-link>
        </div>
      </section>
    </div>

    <div class="boundary-strip">
      <div class="boundary-item">
        <span class="caption">REAL</span>
        <span>S1 IFC 板 / 墙几何 · 16,372 构件 · 19 楼层 · GUID</span>
      </div>
      <div class="boundary-item">
        <span class="caption">SIMULATED</span>
        <span>现场观察 · 防护状态 · 2.5 m 坠落假设 · 1.0 m 暴露策略</span>
      </div>
      <div class="boundary-item">
        <span class="caption">NOT CLAIMED</span>
        <span>真实事故概率 · 现场合规 · 完整模型全量显示</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dashboard {
  padding-top: 30px;
}
.hero {
  display: grid;
  grid-template-columns: minmax(0, 1.2fr) minmax(380px, 0.8fr);
  gap: 34px;
  align-items: center;
  padding: 12px 2px 28px;
}
.hero-eyebrow {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 16px;
}
.hero-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-family: var(--mono);
  font-size: 9px;
  letter-spacing: 0.14em;
  color: var(--teal);
  border: 1px solid rgba(45, 212, 191, 0.28);
  background: rgba(45, 212, 191, 0.06);
  padding: 4px 8px;
  border-radius: 4px;
}
.hero h1 {
  font-size: clamp(30px, 3.2vw, 46px);
  line-height: 1.16;
  letter-spacing: -0.035em;
}
.hero-sub {
  margin-top: 17px;
  max-width: 680px;
  color: var(--muted);
  font-size: 13.5px;
  line-height: 1.85;
}
.hero-sub strong {
  color: var(--text-soft);
  font-weight: 550;
}
.hero-actions {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  margin-top: 22px;
}
.hero-note {
  display: flex;
  align-items: center;
  gap: 7px;
  margin-top: 16px;
  font-size: 10.5px;
  color: var(--dim);
}
.hero-note svg {
  color: var(--teal);
}
.hero-side {
  min-width: 0;
}
.case-orbit {
  padding: 0;
  overflow: hidden;
  position: relative;
}
.case-orbit::before {
  content: "";
  position: absolute;
  inset: -40% -20% auto auto;
  width: 240px;
  height: 240px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(45, 212, 191, 0.14), transparent 65%);
  pointer-events: none;
}
.orbit-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 10px;
  padding: 16px 17px 12px;
}
.orbit-title {
  font-size: 14px;
  font-weight: 600;
  margin-top: 4px;
}
.orbit-map {
  padding: 0 13px;
}
.plan-svg {
  width: 100%;
  height: 150px;
  border: 1px solid var(--line);
  border-radius: 9px;
  background: rgba(5, 13, 24, 0.48);
}
.orbit-legend {
  display: flex;
  gap: 12px;
  margin-top: 8px;
  font-size: 9px;
  color: var(--dim);
}
.orbit-legend span {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}
.dot.teal { background: var(--teal); }
.dot.rose { background: var(--red); }
.dot.amber { background: var(--amber); }
.orbit-meta {
  display: grid;
  grid-template-columns: 1.4fr 1fr 0.8fr;
  gap: 10px;
  padding: 13px 17px;
  border-top: 1px solid var(--line);
  margin-top: 13px;
}
.orbit-meta .small {
  margin-top: 3px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.orbit-cta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding: 11px 17px;
  border: none;
  border-top: 1px solid var(--line);
  background: rgba(45, 212, 191, 0.055);
  color: var(--teal);
  font-size: 11.5px;
  font-weight: 600;
}
.orbit-cta:hover {
  background: rgba(45, 212, 191, 0.1);
}
.metric-row {
  display: grid;
  grid-template-columns: repeat(6, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 16px;
}
.metric {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 14px;
  position: relative;
  overflow: hidden;
}
.metric::after {
  content: "";
  position: absolute;
  left: 0;
  bottom: 0;
  height: 2px;
  width: 100%;
  opacity: 0.45;
  background: currentColor;
}
.metric.accent-teal { color: var(--teal); }
.metric.accent-cyan { color: var(--cyan); }
.metric.accent-blue { color: var(--blue); }
.metric.accent-violet { color: var(--violet); }
.metric.accent-amber { color: var(--amber); }
.metric.accent-green { color: var(--green); }
.metric-icon {
  width: 32px;
  height: 32px;
  flex: none;
  border-radius: 8px;
  display: grid;
  place-items: center;
  background: rgba(148, 163, 184, 0.07);
  border: 1px solid var(--line);
}
.metric .stat {
  color: var(--text);
  font-size: 20px;
}
.metric .stat-label {
  margin-top: 4px;
}
.dashboard-grid {
  display: grid;
  grid-template-columns: minmax(0, 1.55fr) minmax(340px, 0.7fr);
  gap: 16px;
}
.flow-card .card-body {
  padding-top: 17px;
}
.flow-foot {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  margin-top: 18px;
  padding-top: 13px;
  border-top: 1px solid var(--line);
}
.flow-step {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 10px;
  color: var(--dim);
}
.flow-step .mono {
  color: var(--teal);
  font-size: 9px;
}
.status-big {
  display: flex;
  align-items: center;
  gap: 18px;
}
.status-ring {
  width: 92px;
  height: 92px;
  flex: none;
  border-radius: 50%;
  background: conic-gradient(var(--teal) var(--pct), rgba(124, 160, 196, 0.13) 0);
  display: grid;
  place-items: center;
  position: relative;
}
.status-ring::after {
  content: "";
  position: absolute;
  inset: 6px;
  border-radius: 50%;
  background: #0b1728;
}
.status-ring-inner {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: baseline;
  gap: 2px;
}
.status-ring-inner strong {
  font-size: 25px;
  font-family: var(--mono);
}
.status-ring-inner span {
  font-size: 9px;
  color: var(--dim);
}
.status-bars {
  margin-top: 18px;
  display: flex;
  flex-direction: column;
  gap: 9px;
}
.status-bar-row {
  display: grid;
  grid-template-columns: 74px minmax(0, 1fr) 22px;
  align-items: center;
  gap: 9px;
}
.bar {
  height: 4px;
  border-radius: 99px;
  background: rgba(124, 160, 196, 0.13);
  overflow: hidden;
}
.bar span {
  display: block;
  height: 100%;
  border-radius: 99px;
  background: linear-gradient(90deg, var(--teal), var(--cyan));
}
.dashboard-lower {
  display: grid;
  grid-template-columns: minmax(0, 1.3fr) minmax(380px, 0.7fr);
  gap: 16px;
  margin-top: 16px;
}
.data-table td {
  cursor: pointer;
}
.evidence-chain .chain {
  display: flex;
  align-items: stretch;
  gap: 8px;
  flex-wrap: wrap;
}
.chain-item {
  flex: 1;
  min-width: 100px;
  padding: 10px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: rgba(5, 13, 24, 0.42);
  display: flex;
  flex-direction: column;
  gap: 3px;
}
.chain-item .mono {
  font-size: 8px;
  color: var(--teal);
  letter-spacing: 0.1em;
}
.chain-item strong {
  font-size: 11px;
  font-weight: 600;
}
.chain-item small {
  font-size: 9px;
  color: var(--dim);
  line-height: 1.35;
}
.chain-note {
  margin-top: 13px;
  font-size: 10.5px;
  color: var(--dim);
  line-height: 1.65;
}
.boundary-strip {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 1px;
  margin-top: 16px;
  border: 1px solid var(--line);
  border-radius: 10px;
  overflow: hidden;
  background: var(--line);
}
.boundary-item {
  background: rgba(8, 18, 31, 0.8);
  padding: 11px 14px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 10px;
  color: var(--dim);
}
.boundary-item .caption {
  color: var(--muted);
}
@media (max-width: 1280px) {
  .hero {
    grid-template-columns: 1fr;
  }
  .metric-row {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
  .dashboard-grid,
  .dashboard-lower {
    grid-template-columns: 1fr;
  }
}
@media (max-width: 760px) {
  .metric-row,
  .boundary-strip {
    grid-template-columns: 1fr;
  }
  .hero h1 {
    font-size: 30px;
  }
}
</style>
