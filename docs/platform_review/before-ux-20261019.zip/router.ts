import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  scrollBehavior: () => ({ top: 0 }),
  routes: [
    {
      path: '/',
      name: 'dashboard',
      component: () => import('./views/DashboardView.vue'),
      meta: { title: '总览', eyebrow: 'CASE OVERVIEW' },
    },
    {
      path: '/bim',
      name: 'bim',
      component: () => import('./views/BimView.vue'),
      meta: { title: 'BIM 模型', eyebrow: 'BIM WORKSPACE' },
    },
    {
      path: '/cases',
      name: 'cases',
      component: () => import('./views/CasesView.vue'),
      meta: { title: '安全案例', eyebrow: 'SAFETY CASES' },
    },
    {
      path: '/cases/:id',
      name: 'case-detail',
      component: () => import('./views/CaseDetailView.vue'),
      meta: { title: '案例详情', eyebrow: 'SAFETY CASE' },
    },
    {
      path: '/agent',
      name: 'agent',
      component: () => import('./views/AgentView.vue'),
      meta: { title: 'Agent 工作流', eyebrow: 'AGENT TRACE' },
    },
    {
      path: '/knowledge',
      name: 'knowledge',
      component: () => import('./views/KnowledgeView.vue'),
      meta: { title: '规范知识库', eyebrow: 'KNOWLEDGE BASE' },
    },
    {
      path: '/evidence',
      name: 'evidence',
      component: () => import('./views/EvidenceView.vue'),
      meta: { title: '证据库', eyebrow: 'EVIDENCE' },
    },
    {
      path: '/acceptance',
      name: 'acceptance',
      component: () => import('./views/AcceptanceView.vue'),
      meta: { title: '验收实验室', eyebrow: 'ACCEPTANCE LAB' },
    },
    {
      path: '/about',
      name: 'about',
      component: () => import('./views/AboutView.vue'),
      meta: { title: '方案与边界', eyebrow: 'METHOD & BOUNDARY' },
    },
    { path: '/:pathMatch(.*)*', redirect: '/' },
  ],
})

router.afterEach((to) => {
  const title = (to.meta.title as string) || 'BIM 施工安全协同平台'
  document.title = `${title} · BIM 施工安全协同平台`
})

export default router
