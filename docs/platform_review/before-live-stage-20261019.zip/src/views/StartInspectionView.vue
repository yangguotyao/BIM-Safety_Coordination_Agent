<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ArrowRight, Box, Check, CheckCircle2, Image, Loader2, MapPin, ShieldCheck, Sparkles } from 'lucide-vue-next'
import CaseProgress from '../components/CaseProgress.vue'
import { api } from '../api'
import { actorId, errorMessage, refreshSummary, toast } from '../store'
import type { CaseBundle, Evidence } from '../types'
import { formatDateTime } from '../utils'
const router = useRouter()
const rows = ref<Evidence[]>([])
const loading = ref(true)
const busy = ref(false)
const error = ref('')
const selectedId = ref('EV-001')
const title = ref('05 层板边 · 临边防护检查')
const request = ref('全面检查L05区域临边防护和人员暴露风险，结合现场证据与规范依据提出控制措施。')
const asOf = ref('2026-10-16T09:00:00+08:00')
const selected = computed(() => rows.value.find(item => item.evidence_id === selectedId.value))
const scenarios = [
  { id: 'EV-001', title: '临边防护缺失', note: '推荐 · 完整整改闭环', tone: 'red' },
  { id: 'EV-003', title: '栏杆高度不足', note: '观察高度与验收要求', tone: 'amber' },
  { id: 'EV-004', title: '现场信息缺失', note: '演示补证分支', tone: 'blue' },
  { id: 'EV-007', title: '防护正常样例', note: '演示无需整改的检查', tone: 'green' },
]
const observation = (value: unknown) => value === true ? '是' : value === false ? '否' : ({ present:'已设置', absent:'未设置', unknown:'待确认' }[String(value)] || '待确认')
onMounted(async () => {
  try { rows.value = (await api.get<{ rows: Evidence[] }>('/evidence?stage=before')).rows }
  catch (cause) { error.value = errorMessage(cause) }
  finally { loading.value = false }
})
async function start() {
  if (busy.value || !selected.value || !request.value.trim()) return
  busy.value = true
  let createdId = ''
  try {
    const response = await api.post<CaseBundle>('/cases', {
      title: title.value.trim() || '05 层板边安全检查', request_text: request.value.trim(), actor_id: actorId,
      model_id:'S1-bSDD-example', task_id:'TASK-S1-001', zone_id:'ZONE-S1-L05-EDGE',
      as_of:asOf.value, evidence_ids:[selectedId.value],
    })
    createdId = response.case.case_id
    await api.post(`/cases/${createdId}/analyze`)
    await refreshSummary()
    toast('检查已发起，正在分析现场风险。', 'success')
    router.push(`/cases/${createdId}`)
  } catch (cause) {
    toast(errorMessage(cause), 'error', 7000)
    if (createdId) router.push(`/cases/${createdId}`)
  } finally { busy.value = false }
}
</script>

<template>
  <div class="page inspection-page">
    <header class="page-head"><div><div class="eyebrow">新建检查任务</div><h1>发起安全检查</h1><p class="sub">确认检查区域、选择现场证据，描述你要检查的问题。示例资料已预填，可直接开始。</p></div><router-link class="btn" to="/cases">查看已有检查</router-link></header>
    <CaseProgress />
    <div v-if="error" class="notice warn">{{ error }}</div>
    <div class="inspection-layout">
      <form class="inspection-form" @submit.prevent="start">
        <section class="card setup-section"><div class="setup-head"><span>01</span><div><h2>确认检查区域</h2><p>本次围绕同一区域的 BIM 构件与施工作业展开。</p></div><span class="badge tone-green"><Check :size="12" /> 已选定</span></div><div class="scope-box"><span class="scope-icon"><Box :size="28" /></span><div><strong>S1 建设项目 · 05 层板边</strong><p><MapPin :size="12" /> 机电材料转运作业区域</p></div><router-link to="/bim">查看 BIM <ArrowRight :size="13" /></router-link></div><details class="time-option"><summary>检查时间与任务名称</summary><div class="form-row"><div class="field"><label for="check-name">检查任务名称</label><input id="check-name" v-model="title" class="input" /></div><div class="field"><label for="check-time">检查时刻</label><input id="check-time" v-model="asOf" class="input" /></div></div></details></section>

        <section class="card setup-section"><div class="setup-head"><span>02</span><div><h2>选择现场证据</h2><p>首次演示建议使用“临边防护缺失”，走完一条完整流程。</p></div></div><div v-if="loading" class="loading-evidence"><Loader2 :size="17" class="spin" /> 正在读取检查资料</div><div v-else class="scenario-grid"><button v-for="item in scenarios" :key="item.id" type="button" class="scenario" :class="{ selected: selectedId === item.id }" :disabled="!rows.some(row => row.evidence_id === item.id)" @click="selectedId = item.id"><span class="scenario-mark" :class="`tone-${item.tone}`"><Image :size="18" /></span><strong>{{ item.title }}</strong><small>{{ item.note }}</small><CheckCircle2 v-if="selectedId === item.id" :size="16" class="selected-check" /></button></div><details class="other-evidence"><summary>选择其他已有证据</summary><label for="other-evidence">检查前证据</label><select id="other-evidence" v-model="selectedId" class="select"><option v-for="item in rows" :key="item.evidence_id" :value="item.evidence_id">{{ item.label }} · {{ item.evidence_id }}</option></select></details></section>

        <section class="card setup-section"><div class="setup-head"><span>03</span><div><h2>描述检查任务</h2><p>Agent 将根据你的检查重点，选择工具并整理风险与控制措施。</p></div></div><label class="sr-only" for="inspection-request">检查任务描述</label><textarea id="inspection-request" v-model="request" class="textarea request-input" maxlength="1500" required /><div class="task-suggestions"><span>也可以只检查</span><button type="button" @click="request = '只检查L05区域栏杆高度是否满足要求，并提出控制措施。'">栏杆高度</button><button type="button" @click="request = '检查L05区域防护固定与连续性是否满足要求。'">固定与连续性</button><button type="button" @click="request = '检查L05区域人员暴露与距离风险。'">人员暴露</button></div></section>
        <div class="start-check-bar"><div><ShieldCheck :size="18" /><span>分析完成后，由你审核控制措施。</span></div><button class="btn btn-primary btn-lg" :disabled="busy || loading || !selected || !request.trim()"><Loader2 v-if="busy" :size="17" class="spin" /><Sparkles v-else :size="17" /> {{ busy ? '正在发起检查…' : '开始检查' }} <ArrowRight :size="17" /></button></div>
      </form>
      <aside class="inspection-summary"><section class="card evidence-preview"><div class="summary-heading"><h2>本次检查资料</h2><span class="badge tone-blue">{{ selected?.evidence_id || '待选择' }}</span></div><div v-if="selected" class="preview-image"><img :src="selected.image_url" :alt="selected.label" /><span>演示示意图</span></div><div class="preview-body"><h3>{{ selected?.label || '请选择一条现场证据' }}</h3><p>{{ formatDateTime(selected?.captured_at) }}</p><dl v-if="selected"><div><dt>区域</dt><dd>05 层板边</dd></div><div><dt>临边防护</dt><dd>{{ observation(selected.observation.guardrail_state) }}</dd></div><div><dt>作业人员在场</dt><dd>{{ observation(selected.observation.worker_present) }}</dd></div><div><dt>资料性质</dt><dd>模拟现场观察</dd></div></dl></div></section><section class="after-start"><h3>开始后会发生什么？</h3><div><span>1</span><p>关联模型、作业时间和现场证据</p></div><div><span>2</span><p>匹配规范，生成风险结果与候选措施</p></div><div><span>3</span><p>进入检查工作台，完成人工审核和后续处置</p></div><p class="scope-note">BIM 来自 S1 真实模型；证据图与观察为演示输入。上传资料不自动进行视觉识别。</p></section></aside>
    </div>
  </div>
</template>

<style scoped>
.inspection-layout{display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:22px}.inspection-form{display:grid;gap:17px;align-content:start}.setup-section{padding:23px 25px}.setup-head{display:flex;gap:12px;align-items:flex-start;margin-bottom:20px}.setup-head>span:first-child{font-size:12px;font-weight:750;color:var(--blue);padding-top:2px}.setup-head h2{font-size:16px;font-weight:700}.setup-head p{font-size:12px;color:var(--muted);margin-top:6px;line-height:1.7}.setup-head>.badge{margin-left:auto;flex-shrink:0}.scope-box{display:flex;gap:14px;align-items:center;padding:17px;background:var(--panel-2);border-radius:12px;border:1px solid var(--line)}.scope-icon{width:48px;height:48px;display:grid;place-items:center;border-radius:13px;background:#e5eefb;color:#477cae;flex-shrink:0}.scope-box strong{font-size:14px}.scope-box p{display:flex;align-items:center;gap:5px;font-size:11px;color:var(--muted);margin-top:7px}.scope-box a{display:flex;gap:5px;align-items:center;margin-left:auto;font-size:11px;white-space:nowrap}.time-option,.other-evidence{margin-top:17px;font-size:12px;color:var(--muted)}summary{cursor:pointer} .time-option .form-row{margin-top:13px}.scenario-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.scenario{position:relative;display:grid;grid-template-columns:34px 1fr;gap:5px 11px;text-align:left;border:1px solid var(--line);border-radius:11px;padding:15px;background:white;color:var(--text);font:inherit}.scenario:hover{border-color:#96b6e5}.scenario.selected{border-color:var(--blue);box-shadow:0 0 0 1px var(--blue);background:#f5f8ff}.scenario-mark{width:32px;height:35px;display:grid;place-items:center;border-radius:9px;grid-row:1/3}.scenario strong{font-size:13px;font-weight:650;padding-right:13px}.scenario small{font-size:10px;color:var(--muted)}.selected-check{position:absolute;right:10px;top:11px;color:var(--blue)}.other-evidence label{display:block;margin:12px 0 7px}.request-input{min-height:108px;font-size:14px;line-height:1.9}.task-suggestions{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-top:12px;font-size:11px;color:var(--muted)}.task-suggestions button{background:var(--panel-2);border:1px solid var(--line);padding:5px 8px;border-radius:6px;font-size:11px;color:var(--text-soft)}.start-check-bar{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:2px 0 5px}.start-check-bar>div{display:flex;gap:8px;align-items:center;color:var(--muted);font-size:12px}.start-check-bar>div svg{color:var(--green)}.inspection-summary{align-self:start;position:sticky;top:90px}.evidence-preview{overflow:hidden}.summary-heading{display:flex;align-items:center;justify-content:space-between;padding:19px 20px}.summary-heading h2{font-size:14px}.preview-image{height:180px;position:relative;background:#e6edf4}.preview-image img{width:100%;height:100%;object-fit:contain}.preview-image>span{position:absolute;left:12px;bottom:10px;background:#fff8e6e8;color:#9b6a18;border:1px solid #dcc086;padding:4px 7px;border-radius:5px;font-size:10px}.preview-body{padding:20px}.preview-body h3{font-size:15px}.preview-body>p{font-size:11px;color:var(--muted);margin-top:7px}.preview-body dl{margin:19px 0 0;padding-top:15px;border-top:1px solid var(--line);display:grid;gap:12px}.preview-body dl>div{display:flex;justify-content:space-between;gap:10px;font-size:11px}.preview-body dt{color:var(--muted)}.preview-body dd{margin:0;color:var(--text-soft)}.after-start{padding:24px 8px}.after-start h3{font-size:13px;margin-bottom:16px}.after-start>div{display:flex;gap:10px;align-items:flex-start;margin-bottom:15px}.after-start>div>span{width:18px;height:18px;display:grid;place-items:center;border-radius:50%;background:#e0e9f4;color:#6885a4;font-size:10px;flex-shrink:0}.after-start>div p{font-size:11px;color:var(--muted);line-height:1.7}.scope-note{font-size:10px;color:var(--dim);line-height:1.8;border-top:1px solid var(--line);padding-top:17px;margin-top:20px}.loading-evidence{display:flex;gap:9px;align-items:center;justify-content:center;padding:22px;color:var(--muted);font-size:12px}.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}
@media(max-width:1100px){.inspection-layout{grid-template-columns:minmax(0,1fr) 260px;gap:16px}.setup-section{padding:20px}.scenario{padding:13px 10px}.scenario-grid{gap:10px}}
@media(max-width:950px){.inspection-layout{grid-template-columns:minmax(0,1fr)}.inspection-summary{position:static;display:grid;grid-template-columns:1fr 1fr;gap:20px}.preview-image{height:150px}}
@media(max-width:600px){.setup-section{padding:18px}.scenario-grid{grid-template-columns:1fr}.inspection-summary{grid-template-columns:1fr}.after-start{display:none}.scope-box{padding:12px}.scope-box a{font-size:10px}.start-check-bar{align-items:stretch;flex-direction:column}.start-check-bar>div{font-size:11px}.setup-head .badge{display:none}}
</style>
